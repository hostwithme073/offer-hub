<?php
$host = "localhost";
$username = "getiplti_kannada";
$password = "GhzV2N3uJTxQpjdGPpWR"; 
$database = "getiplti_kannada";
// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create `data` table if it doesn't exist
$table_data_sql = "CREATE TABLE IF NOT EXISTS data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    min_amount INT NOT NULL,
    max_amount INT NOT NULL,
    upi VARCHAR(255) NOT NULL
)";
if (!$conn->query($table_data_sql)) {
    die("Error creating table 'data': " . $conn->error);
}

// Insert default values into `data` table if it's empty
$insert_data_sql = "INSERT INTO data (min_amount, max_amount, upi)
                    SELECT 495, 499, 'Testing@ybl' WHERE NOT EXISTS (SELECT 1 FROM data)";
if (!$conn->query($insert_data_sql)) {
    die("Error inserting default data into 'data': " . $conn->error);
}

// Create `user` table if it doesn't exist
$table_user_sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";
if (!$conn->query($table_user_sql)) {
    die("Error creating table 'users': " . $conn->error);
}

// Insert default user if it's empty
$insert_user_sql = "INSERT INTO users (username, password)
                    SELECT 'admin', 'admin123' WHERE NOT EXISTS (SELECT 1 FROM users)";
if (!$conn->query($insert_user_sql)) {
    die("Error inserting default user into 'users': " . $conn->error);
}
?>
